package test.arry;

import java.util.Arrays;

public class BasicPractice1 {
    public static void main(String[] args) {
        // creating an array
        int i[]= {4,5,34,95,82};
        System.out.println(i); // this will return the memory address
        System.out.println(Arrays.toString(i)); // just to print the array in one line by converting it to string

    }
}
