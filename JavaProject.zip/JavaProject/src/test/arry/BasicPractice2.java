package test.arry;

public class BasicPractice2 {
    public static void main(String[] args) {
        // find length of array without using length function
        int arr[]= {4,5,34,95,82};
//        int arr[] ={};
        int count = 0;
        while(count>=0){
            try{
                System.out.println(arr[count]);
                count = count+1;
            }
            catch (Exception e){
                break;
            }
        }
        System.out.println("length is "+count);
    }
}
