package test.arry;

import java.util.Set;
import java.util.TreeSet;

public class RemoveDuplicates {
    public static void main(String[] args) {
        int [] arr = {1,3,5,3,5,2,5,6,7,8,24,23,32,32,23,24,4,2};
        Set<Integer> set = new TreeSet<>();
        for (int j : arr) {
            set.add(j);
        }
        System.out.println(set);
    }
}
