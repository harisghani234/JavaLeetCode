package test;

public class S_Panagram {
    public static void main(String[] args) {
        String s= "The quick brown fox jumps over the lazy dog";
        System.out.println(checkPanagram(s));
    }
    public static boolean checkPanagram(String s) {
        boolean boolArray[] = new boolean[26];
        for (int i = 0; i < s.length(); i++) {
            if(s.charAt(i)-'a'>=0 && s.charAt(i)-'z'<26){
                boolArray[s.charAt(i)- 'a']= true;
            }
        }
        for(int i=0;i<boolArray.length;i++){
            if(boolArray[i]==false){
                return false;
            }
        }
        return true;
    }
}
