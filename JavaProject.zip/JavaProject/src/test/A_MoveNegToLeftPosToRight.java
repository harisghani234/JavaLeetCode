package test;

public class A_MoveNegToLeftPosToRight {
    public static void main(String[] args) {
        int []a = {0,-19,8,-5,51,-2,99,48,6,-4,-12,0};
        int output[]= moveNegativeAndPositive(a);
        for(int i=0;i<output.length;i++){
            System.out.print(output[i]+",");
        }
    }


    public static int[] moveNegativeAndPositive(int[] a){
        int [] temp= new int[a.length];
        int count =0;
        for(int i=0; i<a.length; i++){
            if(a[i]<0){
                temp[count++]=a[i];
            }
        }
        for(int i=0;i<a.length;i++){
            if(a[i]>=0){
                temp[count++]=a[i];
            }
        }
        return temp;
    }
}
