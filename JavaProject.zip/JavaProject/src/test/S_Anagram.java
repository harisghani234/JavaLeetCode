package test;
//Check whether two Strings are anagram of each other

public class S_Anagram {
    public static void main(String[] args) {
//        String s1 = "aliSteenp";
//        String s2 = "siLpeente";
        String s1 = "listen";
        String s2 = "silenT";
        boolean output = checkAnagram(s1, s2);
        System.out.println(output);
    }

    public static boolean checkAnagram(String s1, String s2) {
        int boolArray[] = new int[26];
        if (s1.length() == s2.length()) {
            for(int i =0;i<s1.length();i++) {
                if (s1.charAt(i) - 'a' >= 0 && s1.charAt(i) - 'z' < 26) {
                    boolArray[s1.charAt(i) - 'a'] = boolArray[s1.charAt(i) - 'a'] + 1;
                } else if (s1.charAt(i) - 'A' >= 0 && s1.charAt(i) - 'Z' < 26) {
                    boolArray[s1.charAt(i) - 'A'] = boolArray[s1.charAt(i) - 'A'] + 1;
                }
            }
            for(int i=0;i<s2.length();i++){
                if (s2.charAt(i) - 'a' >= 0 && s2.charAt(i) - 'z' < 26) {
                    boolArray[s2.charAt(i) - 'a'] = boolArray[s2.charAt(i) - 'a'] - 1;
                } else if (s2.charAt(i) - 'A' >= 0 && s2.charAt(i) - 'Z' < 26) {
                    boolArray[s2.charAt(i) - 'A'] = boolArray[s2.charAt(i) - 'A'] - 1;
                }
            }
            for(int i=0;i< boolArray.length;i++){
               if(boolArray[i]>0){
                   System.out.println("it is not a valid Anagram");
                   return false;
               }
            }



        } else {
            System.out.println("Size did not match, hence, not Anagram");
            return false;
        }
        return true;
    }
}

