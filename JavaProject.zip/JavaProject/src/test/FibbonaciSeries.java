package test;

public class FibbonaciSeries {
    public static void main(String[] args) {
        int max_len = 8;
        int f1 = 0;
        int f2=1;
        int f3= 0;
        System.out.print(f1+" "+f2+" ");
        for (int i=0;i<max_len-2; i++){
            f3 =f1+f2;
            System.out.print(f3+" ");
            f1=f2;
            f2=f3;
        }
    }
}
