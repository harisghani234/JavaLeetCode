package test;

public class A_Move0ToLeft {
    public static void main(String[] args) {
        int []a = {3,0,1,6,0,8,0,1};
        int [] output= moveAllZeroToRight(a);
        for(int i=0;i<output.length;i++){
            System.out.print(output[i]+ ",");
        }
        System.out.println("***Move all 0 to left ");
    }

    public static int[] moveAllZeroToRight(int a[]){
        int count = 0;
        for(int i=0; i<a.length; i++) {
            if(a[i]!=0){
                a[count++]= a[i];
            }
        }
        while(count<a.length){
            a[count++]=0;
        }
        return a;
    }



}
