package leetcode.string;

public class LL {
    public static void main(String[] args) {

        int [] input = {11,56,45,34,34};
        int max = input[0];
        int max2 = input[1];
        if(max2>max){
            max = input[1];
            max2 = input[0];
        }
        for(int i=2; i<input.length; i++){
            if(input[i]>max){
                max2 = max;
                max = input[i];
            }else if(input[i]<max && input[i]>max2){
                max2 = input[i];
            }
        }
//        System.out.println(max);
        System.out.println(max2);
    }
}
