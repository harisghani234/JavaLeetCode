package leetcode.string;

public class BuddyString_LC859 {
    public static void main(String[] args) {
        String s = "abcd";
        String goal = "badc";
        System.out.println(buddyStrings(s,goal));
    }
    public static boolean buddyStrings(String s, String goal) {
        if(s.length()!= goal.length())
            return false;
        for(int i=0; i<s.length(); i++){
            if(s.charAt(i)!= goal.charAt(i)){
                StringBuffer s1 = new StringBuffer(s.substring(i, i+2));
                StringBuffer goal1 = new StringBuffer(goal.substring(i, i+2));
                System.out.println(s1);
                goal1.reverse();
                System.out.println(goal1);
                String f1 = s1+s.substring(i+2,s.length());
                String f2 = goal1+goal.substring(i+2,s.length());
                System.out.println("dsafdafdafd");
                System.out.println(f1);
                System.out.println(f2);
                if(f1.toString().equals(f2.toString())){
                    return true;
                }else{
                    return false;
                }
            }

        }
        if(s.length() ==2 && goal.length() == 2){

            StringBuilder sb1 = new StringBuilder(s);
            StringBuilder sb2 = new StringBuilder(goal);
            sb1.reverse();
            if(sb1.toString().equals(sb2.toString())){
                return true;
            }else{
                return false;
            }
        }
        return true;
    }
}
