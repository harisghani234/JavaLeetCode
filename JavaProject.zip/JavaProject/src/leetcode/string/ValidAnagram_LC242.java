package leetcode.string;

import java.util.HashMap;
import java.util.Map;

public class ValidAnagram_LC242 {

    public static void main(String[] args) {
      String s = "anagram";
      String t = "nagaram";
//        System.out.println(isAnagram(s,t));
        System.out.println(usignHashmpa(s,t));

    }
    // t is anagram of s
    public static boolean isAnagram(String s, String t) {
        if(s.length()!=t.length())
            return false;
        int [] array = new int[26];
        for(int i=0; i<s.length(); i++){
            char c = s.charAt(i);
            int index = c-'a';
            array[index]=array[index]+1;
        }
        for(int i=0; i<t.length(); i++){
            char c = t.charAt(i);
            int index = c-'a';
            array[index]=array[index]-1;
        }
        for(int i=0; i<array.length; i++){
            if(array[i]!=0){
                return false;

            }
        }

        return true;
    }
    public static boolean usignHashmpa(String s , String t){
        HashMap<Character, Integer> hmap = new HashMap<>();
        for(int i=0; i<s.length(); i++){
            if(hmap.containsKey(s.charAt(i)))
                hmap.put(s.charAt(i), hmap.get(s.charAt(i))+1);
            else
                hmap.put(s.charAt(i), 1);
        }
        for(int i=0; i<t.length(); i++){
            if(hmap.containsKey(t.charAt(i))){
                hmap.put(t.charAt(i), hmap.get(t.charAt(i))-1);
            }else{
                return false;
            }
        }
        for(Map.Entry<Character, Integer> entry: hmap.entrySet()){
            if(entry.getValue()!=0){
                return false;
            }
        }


        return true;
    }
}
