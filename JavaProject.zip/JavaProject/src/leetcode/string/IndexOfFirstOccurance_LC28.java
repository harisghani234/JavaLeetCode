package leetcode.string;

public class IndexOfFirstOccurance_LC28 {
    public static void main(String[] args) {
//        Input: haystack = "sadbutsad", needle = "sad"
//        Output: 0
        String haystack = "sadbutsad";
        String needle = "sad";
        int result = strStr(haystack, needle);
        System.out.println(result);
    }
    // base to understand this program
    // if you have a string of 10 characters, then find all subsequnce substring from index 0 to last index with 3 characters
    public void testProgam(String haystack, int newStrLength){
        for(int i=0; i<haystack.length(); i++){
            String output = haystack.substring(i,newStrLength+i);
            System.out.println(output);
        }
    }

    public static int strStr(String haystack, String needle) {
        int count = 1;
        if(haystack.length()<needle.length() || haystack.length() == 0 || needle.length() == 0)
            return -1;

        for(int i=0; i<=haystack.length()-needle.length(); i++){
            System.out.println(haystack.substring(i,needle.length()+i));
            String word = haystack.substring(i,needle.length()+i);
            if(word.equals(needle))
                return i;
        }
        return -1;
    }

}



