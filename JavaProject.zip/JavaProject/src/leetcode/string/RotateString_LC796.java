package leetcode.string;

public class RotateString_LC796 {
    public static void main(String[] args) {
        String s = "abcde";
        String goal = "cdeab";
//        StringBuilder sb1 = new StringBuilder();
//        StringBuilder sb2 = new StringBuilder();
//        System.out.println(sb1.append(s.substring(1,s.length())).reverse());
//        System.out.println(sb2.append(s.substring(0,1)).reverse());
//        System.out.println(sb1.append(sb2));
        System.out.println(rotateString(s,goal));
    }

    public static boolean rotateString(String s, String goal) {
         for(int i=0; i<s.length();i++){
             StringBuilder sb1 = new StringBuilder("");
             StringBuilder sb2 = new StringBuilder("");
            sb1.append(s.substring(i,s.length())).reverse();
             System.out.println("sfadfadsadfad--- "+sb1);
            sb2.append(s.substring(0,i)).reverse();
            sb1.append(sb2);
            System.out.println(sb1);
            if(sb1.toString().equals(goal)){
                System.out.println("found");
                return true;
            }

        }
        return false;
    }
}
