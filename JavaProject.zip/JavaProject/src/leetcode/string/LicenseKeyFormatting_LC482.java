package leetcode.string;

public class LicenseKeyFormatting_LC482 {
    public static void main(String[] args) {
        String s = "--a-a-a-a--";
        int k = 2;
        System.out.println(licenseKeyFormatting(s,k));
    }

    public static String licenseKeyFormatting(String s, int k) {
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for(int i=s.length()-1;i>=0; i--){
            if(s.charAt(i)=='-')
                continue;
            sb.append(s.charAt(i));
            count++;
            if(k == count){
                sb.append('-');
                count = 0;
            }
        }
        int count1 =0;
        String result = sb.reverse().toString().toUpperCase();
        for(int i=0; i<result.length();i++){
            if(result.charAt(i)=='-'){
                count1++;
            }else{
                break;
            }
        }
        return result.substring(count1, result.length());

    }
}
