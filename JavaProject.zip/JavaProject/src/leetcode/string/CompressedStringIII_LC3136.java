package leetcode.string;

public class CompressedStringIII_LC3136 {
    public static void main(String[] args) {
        String word = "aaaaaaaaaaaaaabb";
        System.out.println(compressedString(word));
    }

    public static String compressedString(String word) {
        StringBuilder compressed = new StringBuilder();
        int count = 1;
        char c = word.charAt(0);
        int i = 1;
        while(i<word.length()){

            if(word.charAt(i) ==  c && count<9){
                count++;
                i++;
            }else{
                compressed.append(count).append(c);
                count=1;
                c = word.charAt(i);
                i++;
            }
            if(i==word.length()){
                compressed.append(count).append(c);
            }
        }


        return compressed.toString();
    }
}
