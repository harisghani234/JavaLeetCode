package leetcode.string;

public class MultiplyString_LC43 {
    public static void main(String[] args) {
//        String num1 = "2";
//        String num2 = "3";
        String num1 = "123";
        String num2 = "456";
        String result = multiply(num1, num2);
        System.out.println(result);



    }

    public static String multiply(String num1, String num2) {
        String output = "";
        long n1 = Long.parseLong(num1);
        long n2 = Long.parseLong(num2);
        long result = n1*n2;
        output = Long.toString(result);
        return  output;
    }
}
