package leetcode.string;

public class StringCompression_Apple {

    public static void main(String[] args) {
        String s2 = "aaabbccccd";
        String s3 = "aaabbccccddd";
        String s4 = "aaaaaaaaaa";
        stringCompression(s2);
        stringCompression(s3);
        stringCompression(s4);

    }



    static void stringCompression(String s){
        int lp = 0;
        int rp = 1;
        int count =1;
        String output = "";
        while(rp<s.length()){
            if(s.charAt(lp) == s.charAt(rp)){
                count++;
            }else{
                output = output+s.charAt(lp)+count;
                lp = rp;
                count = 1;
            }
            if(rp==s.length()-1){
                output = output+s.charAt(lp)+count;
            }
            rp++;
        }
        System.out.println(output);
    }
}
