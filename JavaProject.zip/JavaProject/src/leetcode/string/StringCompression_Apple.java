package leetcode.string;

public class StringCompression_Apple {

    public static void main(String[] args) {
        String s2 = "aaabbccccd";
        String s3 = "aaabbccccddd";
        String s4 = "aaaaaaaaaa";
        stringCompression(s2);
        stringCompression2(s2);
        stringCompression(s3);
        stringCompression2(s3);
        stringCompression(s4);
        stringCompression2(s4);

    }



    static void stringCompression(String s){
        int lp = 0;
        int rp = 1;
        int count =1;
        String output = "";
        while(rp<s.length()){
            if(s.charAt(lp) == s.charAt(rp)){
                count++;
            }else{
                output = output+s.charAt(lp)+count;
                lp = rp;
                count = 1;
            }
            if(rp==s.length()-1){
                output = output+s.charAt(lp)+count;
            }
            rp++;
        }
        System.out.println(output);
    }
    static void stringCompression2(String s){
        int l =0;
        int r =1;
        int count = 1;
        String output = s.charAt(l)+"";
        while(r<s.length()){
            if(s.charAt(l) == s.charAt(r)){
                count++;
                r++;
            }else{
                output = output+count;
                count = 1;
                output = output + s.charAt(r);
                l=r ;
                r++;
            }
            if(r == s.length()){
                output = output + count;
            }
        }
        System.out.println(output);
    }
}
