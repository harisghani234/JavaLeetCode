package leetcode.string;

public class GoarParser_LC1678 {
    //    Input: command = "G()(al)"
//    Output: "Goal"
//    Input: command = "G()()()()(al)"
//    Output: "Gooooal"
    public static void main(String[] args) {
        String command = "G()(al)";
        System.out.println(interpret(command));
    }

    public static String interpret(String command) {
        command = command.replace("()", "o");
        command = command.replace("(al)", "al");
        return command;
    }
}
