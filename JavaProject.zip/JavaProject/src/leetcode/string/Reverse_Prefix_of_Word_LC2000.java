package leetcode.string;

public class Reverse_Prefix_of_Word_LC2000 {
    public static void main(String[] args) {
        String s = "abcdefd";
        char ch = 'd';
        System.out.println(usingBruteForce(s, ch));
        System.out.println(reversePrefix(s, ch));
    }

    public static String reversePrefix(String word, char ch) {
        StringBuilder sb = new StringBuilder("");
        boolean flag = false;
            for(int i =0; i<word.length(); i++){
                if(word.charAt(i)==ch){
                    if(!flag) {
                        sb.append(word.charAt(i)).reverse();
                        flag = true;
                    }else{
                        sb.append(word.charAt(i));
                    }

                }else{
                     sb.append(word.charAt(i));
                }
            }
        return sb.toString();

    }

    public static String usingBruteForce(String word, char ch){
        String ouput = "";
        int index = 0;
        for(int i=0; i<word.length(); i++){
            if(word.charAt(i)== ch) {
                index = i;
                break;
            }
        }
        if(index==0)
            return word;
        for(int i=index; i>=0 ; i--){
            ouput = ouput + word.charAt(i);
        }
        for(int i=index+1; i<word.length();i++){
            ouput = ouput + word.charAt(i);
        }

        return ouput;
    }

    /**
     * best solution with minimal logic
     * @param word
     * @param ch
     * @return
     */
    public static String usingBruteForce1(String word, char ch){
        StringBuffer sb = new StringBuffer();
        int index = 0;
        for(int i=0; i<word.length(); i++){
            if(word.charAt(i)== ch) {
                index = i;
                break;
            }
        }
        sb.append(word.substring(0,index+1));
        sb.reverse();
        sb.append(word.substring(index+1,word.length()));
        return sb.toString();
    }

    public static String simpleLogic(String word, char ch ){
        StringBuffer sb = new StringBuffer();
        for( int i=0; i<word.length();i++){
            sb.append(word.charAt(i));
            if(word.charAt(i) == ch){
                sb.reverse();
                sb.append(word.substring(i+1,word.length()));
                break;
            }
        }
        return sb.toString();
    }
}
