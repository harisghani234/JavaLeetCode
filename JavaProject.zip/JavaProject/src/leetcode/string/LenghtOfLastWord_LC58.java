package leetcode.string;

public class LenghtOfLastWord_LC58 {
    public static void main(String[] args) {
        String s = "   fly me   to   the moon  ";
        int result = 0;
        boolean charStarted = false;
        for (int i = s.length() - 1; i >= 0; i--) {
            if (s.charAt(i) == ' ') {
                if(charStarted)
                    break;
            } else {
                charStarted = true;
                result++;
            }
        }
        System.out.println(result);
    }
}
