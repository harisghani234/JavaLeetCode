package leetcode.string;

public class Maximum_Repeating_Substring_LC1668 {
    public static void main(String[] args) {
        String sequence = "ababc";
        String word = "ab";
        System.out.println(maxRepeating(sequence, word));
    }


    public static int maxRepeating(String sequence, String word) {
        int result = 0;
        int word_pointer = 0;
        for(int i =0; i<sequence.length(); i++){
            if(word_pointer<word.length() && sequence.charAt(i)==word.charAt(word_pointer)){
                if(word_pointer==word.length()-1){
                    result++;
                    word_pointer=0;
                }else {
                    word_pointer++;
                }
            }else{
                word_pointer = 0;
            }
        }
        return result;

    }
}
