package leetcode.string;

public class StringExpansion {
    public static void main(String[] args) {
        String s =  "a2b4c2";
        expandString(s);
    }
    static void expandString(String s){
       int p1 = 0;
       int p2 = 1;
       String output = "";
       while(p2<s.length() && p1<s.length()) {
           output = output+s.charAt(p1);
           int numberAtPointer2 = s.charAt(p2)-'0';
           for(int i=0; i<numberAtPointer2-1; i++){
               output= output+s.charAt(p1);
           }
           p1 = p1+2;
           p2 = p2+2;
           System.out.println(output);
       }
    }

    static boolean is_char_a_digit(char c){
        if(c-'a'>=0 && c-'a'<26)
            return false;
        return true;
    }
}
