package leetcode.string;

public class RepeatedSubstring_LC459 {
    public static void main(String[] args) {
        String s = "abcabcd";
        System.out.println(repeatedSubstringPattern(s));

    }

    public static boolean repeatedSubstringPattern(String s) {
        int indexLeft = 0;
        String subStr = s.substring(indexLeft,1);
        boolean flag = false;
        indexLeft =1;
        for(int i =1; i<s.length();i++){
            int indexRight = i+subStr.length();
            if(indexLeft>s.length() || indexRight>s.length()){
                break;
            }
            if(subStr.equals(s.substring(indexLeft, indexRight))){
                System.out.println("inside if block");
                flag = true;
                i=indexRight;
            }else{
                subStr = subStr + s.charAt(i);
                indexLeft = i+1;
                if(flag){
                    flag = false;
                }
            }

        }
        if(flag)
            return true;
        return false;


    }

}
