package leetcode.string;

import java.util.Arrays;

public class ReverseVowels_LC345 {
    public static void main(String[] args) {
        System.out.println(reverseVowels("hello"));
//        System.out.println(reverseVowels("ab,."));
//        System.out.println(reverseVowels("aA"));
//        System.out.println(reverseVowels("leetcode"));

    }


    public static String reverseVowels(String s) {
        char [] arr = s.toCharArray();
        int l =0;
        int r = s.length()-1;
        while (l<r){
            if(!vowelCheck(s.charAt(l)))
                l++;
            if(!vowelCheck(s.charAt(r)))
                r--;
            if(vowelCheck(s.charAt(l)) && vowelCheck(s.charAt(r))){
                char temp = s.charAt(l);
                arr[l]=s.charAt(r);
                arr[r]=temp;
                l++;r--;
            }
        }
//        String s = arr.toString();
        return new String(arr);
    }

    public static boolean vowelCheck(char c) {
        if(!(c == 'a' ||c == 'e' ||c == 'i' ||c == 'o' ||c == 'u'  || c == 'A' ||c == 'E' ||c == 'I' ||c == 'O' ||c == 'U') )
            return false;
        return true;
    }
}
