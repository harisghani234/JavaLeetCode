package leetcode.string;

import java.awt.*;
import java.util.*;
import java.util.List;

public class GroupAnagram {
    public static void main(String[] args) {
        String [] strs = {"eat","tea","tan","ate","nat","bat"};
        groupAnagrams1(strs);
    }

    public static List<List<String>> groupAnagrams(String[] strs) {
        HashMap<String, List<String>> hmap = new HashMap<>();
        for(int i=0; i<strs.length; i++){
            char [] charArray = strs[i].toCharArray();
            Arrays.sort(charArray);
            String s = new String(charArray);
            if(hmap.containsKey(s)){
                List<String> li2 = hmap.get(s);
                li2.add(strs[i]);
                hmap.put(s, li2);
            }else{
                List<String> li = new ArrayList<>();
                li.add(strs[i]);
                hmap.put(s, li);
            }
        }
        List<List<String>> result = new ArrayList<>();
        for(Map.Entry<String, List<String>> map : hmap.entrySet()){
            result.add(map.getValue());
        }
       return result;

    }

    private static void groupAnagrams1(String[] strs){
        HashMap<String, List<String>> hmap = new HashMap<>();
        for(int i=0; i<strs.length; i++){
            char [] charArray = strs[i].toCharArray();
            Arrays.sort(charArray);
            String s = new String(charArray);
            if(hmap.containsKey(s)){
                List<String> li2 = hmap.get(s);
                li2.add(strs[i]);
                hmap.put(s, li2);
            }else{
                List<String> li = new ArrayList<>();
                li.add(strs[i]);
                hmap.put(s, li);
            }
        }
        List<List<String>> result = new ArrayList<>();
        for(Map.Entry<String, List<String>> map : hmap.entrySet()){
            result.add(map.getValue());
        }
        System.out.println(result);
    }

//    public static String findCharAndOcc(String s){
//        LinkedHashMap<Character, Integer> hm = new LinkedHashMap<>();
//        for(int i=0; i<s.length(); i++){
//            if(hm.containsKey(s.charAt(i)))
//                hm.put(s.charAt(i),hm.get(s.charAt(i))+1);
//            else
//                hm.put(s.charAt(i), 1);
//        }
//
//    }

}
