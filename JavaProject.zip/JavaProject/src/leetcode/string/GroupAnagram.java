package leetcode.string;

import java.util.*;

public class GroupAnagram {
    public static void main(String[] args) {
        String [] strs = {"eat","tea","tan","ate","nat","bat"};
        groupAnagrams(strs);
    }

    public static List<List<String>> groupAnagrams(String[] strs) {
        List<List<String>> list = new ArrayList<>();
        HashMap<String, String> hmap = new HashMap<>();
        for( int i=0; i<strs.length; i++){
            String word = strs[i];

        }



        return list;

    }

//    public static String findCharAndOcc(String s){
//        LinkedHashMap<Character, Integer> hm = new LinkedHashMap<>();
//        for(int i=0; i<s.length(); i++){
//            if(hm.containsKey(s.charAt(i)))
//                hm.put(s.charAt(i),hm.get(s.charAt(i))+1);
//            else
//                hm.put(s.charAt(i), 1);
//        }
//
//    }

}
