package leetcode.string;

import java.util.Stack;

public class BackspaceStringCompare_LC844 {
    public static void main(String[] args) {
        String s = "ab#c";
        String t = "ad#c#";
        System.out.println(backspaceCompare(s,t));
    }



    public static boolean backspaceCompare(String s, String t) {
        Stack<Character> stack = new Stack<>();
        for(int i=0; i<s.length();i++){
            if(s.charAt(i)=='#'){
                stack.pop();
            }else {
                stack.push(s.charAt(i));
            }
        }
        String s1 = String.valueOf(stack);
        Stack<Character> stack2 = new Stack<>();
        for(int i=0; i<t.length();i++){
            if(t.charAt(i)=='#'){
                stack2.pop();
            }else {
                stack2.push(t.charAt(i));
            }
        }
        String t1 = String.valueOf(stack2);
        if(!s1.equals(t1))
            return false;


        return true;
    }
}
