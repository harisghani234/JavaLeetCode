package leetcode.string;

public class NumberOfSegmentInString_LC434 {
    public static void main(String[] args) {
        String s1= "Hello, my name is John";
        String s2= "Hello";
        String s3= "";
        String s4= ", , , ,        a, eaefa";
        System.out.println(countSegments(s1));
        System.out.println(countSegments(s2));
        System.out.println(countSegments(s3));
        System.out.println(countSegments(s4));
    }
    public static int countSegments(String s) {
        int result = 0;
        if(s.length() ==0)
            return result;
        String [] arr = s.split(" ");
        result = arr.length;
        for(int i=0; i<arr.length; i++){
            if(arr[i] == ""){
                result --;
            }
        }
        return result;
    }
}
