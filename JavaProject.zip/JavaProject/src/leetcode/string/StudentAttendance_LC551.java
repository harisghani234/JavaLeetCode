package leetcode.string;

public class StudentAttendance_LC551 {
    public static void main(String[] args) {
        System.out.println(checkRecord("ALLAPPL"));
    }

    public static boolean checkRecord(String s) {
        int p_count = 0;
        int a_count = 0;
        int l_count = 0;
        for(int i=0; i<s.length();i++){
            if(s.charAt(i)== 'A'){
                a_count++;
                System.out.println("count of a "+ a_count);
                if(a_count>=2){
                    return false;
                }
            }else if(s.charAt(i)== 'L'){
                while(i<s.length() && s.charAt(i)=='L' ){
                    l_count++;
                    System.out.println("he  "+ i);
                    System.out.println(l_count);
                    if(l_count>=3) {
                        return false;
                    }
                    i++;
                }
                l_count=0;
                i--;
            }
        }
        return true;

    }
}
