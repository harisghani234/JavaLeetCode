package leetcode;

import java.util.HashMap;

public class Isomorphic {
    public static void main(String[] args) {
        String s1 = "paper";
        String s2 = "titli";
        boolean status = isIsomorphic(s1, s2);
        if (status == true) {
            System.out.println("isomorphic");
        } else {
            System.out.println("not isomorphic");
        }
    }

    public static boolean isIsomorphic(String s, String t) {
        if(s.length() != t.length()){
            return false;
        }
        HashMap<Character, Character> hmap = new HashMap<>();
        for(int i=0;i<s.length();i++){
            if(hmap.containsKey(s.charAt(i))){
                if(hmap.get(s.charAt(i))!=t.charAt(i)){
                    return false;
                }
            }
            else if(hmap.containsValue(t.charAt(i))){
                return false;
            }
            else{
                hmap.put(s.charAt(i), t.charAt(i));
            }
        }
        return true;
    }
}
