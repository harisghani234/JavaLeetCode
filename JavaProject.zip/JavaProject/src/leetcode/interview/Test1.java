package leetcode.interview;

public class Test1 {
    public static void main(String[] args) {
//        String s = "haris1234";
//        StringBuilder output = new StringBuilder();
        int n = 30;
        int a=100;
        int b = 108;

        boolean status = true;
        for(int i=2; i<n/2; i++){
            if(n%i==0){
                status = false;
                break;
            }
        }
        if(status)
            System.out.println("prime");
        else
            System.out.println("not prime");

    }
}
