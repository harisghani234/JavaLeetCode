package leetcode.interview;

public class Apexon {
    public static void main(String[] args) {

        String s = "Welcome to apexon";
        StringBuilder sb = new StringBuilder();

        String [] word = s.split(" ");
        for(int i=word.length-1; i>=0; i--){
            char c = Character.toUpperCase(word[i].charAt(0));
            sb.append(word[i].replace(word[i].charAt(0), c));
            sb.append(" ");
        }
        System.out.println(sb);
    }
}
