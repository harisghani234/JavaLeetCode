package leetcode.interview;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Mindtree {
    public static void main(String[] args) {
        round1();

    }

    private static void round1() {

    }
}
