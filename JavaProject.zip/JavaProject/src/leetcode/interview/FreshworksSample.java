package leetcode.interview;


public class FreshworksSample {
    public static void main(String[] args) {
        String s= "AABBAABBAACAACDDD";
        int i =0, j=1, temp =1, count = 3;
        char c = s.charAt(i);
        String ouput = "";
        while(j<s.length()){
            if(c == s.charAt(j)){
                temp++;
                if(temp == count){
                    j++;
                    i=j;
                    j++;
                    temp = 1;
                    if(j == s.length()+1){
                        continue;
                    }
                    c = s.charAt(i);
                }else{
                    j++;
                }
            }
            else{
                ouput = ouput+s.substring(i,j);
                i = j;
                c = s.charAt(i);
                j++;
                temp = 1;
            }
            if(j==s.length() & temp<count){
                ouput = ouput+s.substring(i,j);
            }
        }
        System.out.println(ouput);
    }
}

