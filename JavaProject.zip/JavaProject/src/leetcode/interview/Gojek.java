package leetcode.interview;

public class Gojek {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
