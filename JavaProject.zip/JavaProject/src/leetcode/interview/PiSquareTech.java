package leetcode.interview;

public class PiSquareTech {
    public static void main(String[] args) {
//        Problem Statement:
//        You need to make a package of chocolate that weighs exactly goal kilos. You have:
//
//        Small bars that weigh 1 kilo each.
//        Big bars that weigh 5 kilos each.
//        You must use the big bars first, then use the small bars to make up the remaining weight. Your task is to determine the minimum number of small bars needed
//        to reach the exact weight of goal kilos. If it’s not possible to make the package with the given bars, return -1.
//
//        Examples:
//        makeChocolate(4, 1, 9) → 4
//        (You need to use 1 big bar (5 kilos) and 4 small bars (4 kilos) to reach the goal of 9 kilos.)
//
//        makeChocolate(4, 1, 10) → -1
//        (Even though you have enough bars, you can't reach exactly 10 kilos using the given bars.)
//
//        makeChocolate(4, 1, 7) → 2
//        (You use 1 big bar (5 kilos) and 2 small bars (2 kilos) to reach the goal of 7 kilos.)
//        int result = makeChocolate(4,1,9);
        int result = makeChocolate(4,1,7);
        System.out.println(result);

    }

    static int makeChocolate(int smallBars, int bigBarsSize, int goalKilos){
        int bigBars = 5*bigBarsSize;
        int needOfSmallBars = goalKilos%bigBars;
        int reqSmallBars = goalKilos - bigBars;
        if(needOfSmallBars>= reqSmallBars)
            return reqSmallBars;
        return -1;
    }
}
