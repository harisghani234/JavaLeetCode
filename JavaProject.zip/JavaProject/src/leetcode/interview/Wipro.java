package leetcode.interview;

public class Wipro {
    public static void main(String[] args) {
        int arr[] = {1,2,3};
        int n = 3;
        System.out.println(peakElement(arr, n));
//        int l =1;
//        while(l<array.length-1){
//            if(array[l]>array[l-1] && array[l]>array[l+1]){
//                System.out.println(array[l]);
//            }
//            l++;
//        }
    }


    public static int peakElement(int[] arr,int n)
    {
        int l=1;
        if(n<=arr[0] || n>=arr[arr.length-1])
            return 1;
        while(l<arr.length-1){
            if(arr[l]>arr[l-1] && arr[l]>arr[l+1])
                return 1;
            l++;
        }
        return 0;
    }
}
