package leetcode.interview;

public class Revrr {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
