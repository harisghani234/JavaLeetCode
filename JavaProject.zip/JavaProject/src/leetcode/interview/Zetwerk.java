package leetcode.interview;

import javax.swing.*;
import java.util.*;

public class Zetwerk {
    public static void main(String[] args) {
        // online coding test
        String str1 = "rkodlyw";
        String str2 = "world";
        System.out.println(word1ContainsWord2(str1, str2));
        // find maxOccurance of element but the max occurance should print only if the occurance is >=half of array length
        int[] array = {1, 3, 2, 3, 6, 8, 8, 3, 3, 3, 8};
        findMaxOccurance(array);
        // group anagaram program from leetcode no 29
        String[] strs = {"eat", "tea", "tan", "ate", "nat", "bat"};
//        Output: [["bat"],["nat","tan"],["ate","eat","tea"]]
        groupAnagram(strs);

    }


    //        System.out.println(word1ContainsWord2(str1, str2));
    public static boolean word1ContainsWord2(String str1, String str2) {
        if (str1.length() == 0 || str1.length() < str2.length())
            return false;
        HashMap<Character, Integer> hm1 = new HashMap<>();
        HashMap<Character, Integer> hm2 = new HashMap<>();
        for (int i = 0; i < str1.length(); i++) {
            if (hm1.containsKey(str1.charAt(i)))
                hm1.put(str1.charAt(i), hm1.get(str1.charAt(i)) + 1);
            else
                hm1.put(str1.charAt(i), 1);
        }
        for (int i = 0; i < str2.length(); i++) {
            if (hm2.containsKey(str2.charAt(i)))
                hm2.put(str2.charAt(i), hm2.get(str2.charAt(i)) + 1);
            else
                hm2.put(str2.charAt(i), 1);
        }

        for (Map.Entry<Character, Integer> entry : hm2.entrySet()) {
            if (hm1.containsKey(entry.getKey())) {
                if (hm1.get(entry.getKey()) != entry.getValue())
                    return false;
            } else {
                return false;
            }
        }
        return true;
    }

    public static void findMaxOccurance(int[] array) {
        int matchCriteria = array.length / 2;
        int maxValue = 0;
        int result = 0;
        HashMap<Integer, Integer> hmap = new HashMap<>();
        for (int i = 0; i < array.length; i++) {
            if (hmap.containsKey(array[i])) {
                hmap.put(array[i], hmap.get(array[i]) + 1);
                if (hmap.get(array[i]) >= matchCriteria) {
                    if (maxValue < hmap.get(array[i])) {
                        maxValue = hmap.get(array[i]);
                        result = array[i];
                    }
                }
            } else
                hmap.put(array[i], 1);
        }
        System.out.println(result);
    }

    public static void groupAnagram(String[] strs) {
        System.out.println("\n******");
        HashMap<String, List<String>> hmap = new HashMap<>();
        for (int i = 0; i < strs.length; i++) {
            char[] strsArray = strs[i].toCharArray();
            Arrays.sort(strsArray);
            String sortedString = String.valueOf(strsArray);
            System.out.println(sortedString);
            if (hmap.containsKey(sortedString)) {
                hmap.get(sortedString).add(strs[i]);
            } else {
                hmap.put(sortedString, new ArrayList<>());
                hmap.get(sortedString).add(strs[i]);
            }
        }
        System.out.println(hmap);
    }
}

