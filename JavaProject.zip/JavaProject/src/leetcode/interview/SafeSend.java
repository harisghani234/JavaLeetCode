package leetcode.interview;

public class SafeSend {
    public static void main(String[] args) {
        String str = "12xy34";
        String word = "xy";
        int l1 = 0;
        int l2 =0;
        while(l1<str.length() &&l2<word.length()){
            if(str.charAt(l1)!=word.charAt(l2)){
                str = str.replace(str.charAt(l1),'+');
                l1++;
                continue;
            }
            if(str.charAt(l1)==word.charAt(l2)){
                l1++;l2++;
            }


        }
        System.out.println(str);
    }
}
