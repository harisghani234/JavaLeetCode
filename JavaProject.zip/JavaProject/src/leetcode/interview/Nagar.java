package leetcode.interview;

public class Nagar {
    public static void main(String[] args) {
//        String s = "Aired 00:00 ago today";
//        round1(s);
        String input =  "Apple";
        toggleFunction(input);
//        Output: aPPLE
//
//        input: MoHAn
//        output: mOhaN
//
//        input: india
//        output: INDIA
//
//        input: BANGALORE
//        output:bangalore
//

    }

    public static void round1(String s){
        String [] array = s.split(" ");
        boolean flag = true;
        String [] array2 = array[1].split(":");
        int hour = Integer.parseInt(array2[0]);
        int minute = Integer.parseInt(array2[1]);
        if(!(hour>=00 && hour<24)){
            flag = false;
        }
        if(!(minute>=00 && minute<60)){
            flag = false;
        }
        if(flag)
            System.out.println("its correct format");
        else
            System.out.println("its invalid format");

    }

    public static void toggleFunction(String s){
        //Apple -> aPPLE
        System.out.println('a'-0);
        System.out.println('A'-0);
        for(int i=0; i<s.length(); i++){
//            System.out.println(s.charAt(i)-0);
//            System.out.println();
            if(s.charAt(i)-'a'>=0 && s.charAt(i)-'z'<=25){
                // its a small letter
            }
//            if else(s.charAt(i)-'A'>=0 && s.charAt(i)-'Z'<=25){
//
//            }
        }
    }
}
