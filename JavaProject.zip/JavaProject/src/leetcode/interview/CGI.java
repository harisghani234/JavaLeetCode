package leetcode.interview;

import java.util.ArrayList;
import java.util.List;

public class CGI {
    public static void main(String[] args) {

//        Input :"!4@T#6S%1E*9T"
//
//        Output : “TEST 1469"
        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();

        String s = "!4@T#6S%1E*9T";
        List<Integer> li = new ArrayList<>();
//        for(int i=0; i<s.length(); i++){
//            if(isValidCharDigit(s.charAt(i))){
//                if(isChar(s.charAt(i))){
//                    sb1.append(s.charAt(i));
//                }else if(isNumber(s.charAt(i))){
//                    sb2.append(s.charAt(i));
//                }
//            }
//        }
//        sb1.reverse();
//        System.out.println(sb1.append(sb2));

        for(int i=0; i<s.length();i++){
            if(Character.isDigit(s.charAt(i))){
                li.add(s.charAt(i)-'0');
                continue;
            }
            if(Character.isAlphabetic(s.charAt(i))){
                sb1.append(s.charAt(i));
            }
        }
        System.out.println(sb1.reverse());
        System.out.println(li);

    }

    public static boolean isValidCharDigit(char c){
        if(c-'a'>=0 && c-'a'<26 )
            return true;
        if(c-'A'>=0 && c-'A'<26)
            return true;
        if(c-'0'>=0 && c-'0'<=9)
            return true;
        return false;
    }

    public static boolean isNumber(char c){
        if(c-'0'>=0 && c-'0'<=9)
            return true;
        return false;
    }
    public static boolean isChar(char c){
        if(c-'a'>=0 && c-'a'<26 )
            return true;
        if(c-'A'>=0 && c-'A'<26)
            return true;
        return false;
    }
}
