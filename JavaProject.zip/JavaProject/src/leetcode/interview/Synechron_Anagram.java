package leetcode.interview;

public class Synechron_Anagram {
    public static void main(String[] args) {
        String s1 = "silent";
        String s2 = "listen";
        int [] arr = new int[26];
        boolean status = true;
        for(int i=0;i<s1.length();i++){
            int index = s1.charAt(i)-'a';
            arr[index]= arr[index]+1;
        }
        for(int i=0;i<s2.length();i++){
            int index = s2.charAt(i)-'a';
            arr[index]= arr[index]-1;
        }
        for(int i=0;i<arr.length;i++){
            if(arr[i]>=1){
                status = false;
                break;
            }
        }

        if(status)
            System.out.println("Anagram");
        else
            System.out.println("not anagram");
    }
}
