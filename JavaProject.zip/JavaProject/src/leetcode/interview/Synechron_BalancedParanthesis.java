package leetcode.interview;

import java.util.Stack;

public class Synechron_BalancedParanthesis {
    public static void main(String[] args) {
        String s = "[it was{Saturday afternoon(and we cooked) meal} outside]"; //Correct
//        String s = "[it was{Saturday afternoon(and we cooked) meal] outside}"; //Incorrect

//        String s = "[it was]Saturday {afternoon and} we (cooked meal) outside"; //Correct
//        String s = "[it was]Saturday {afternoon and) we (cooked meal} outside"; //Incorrect

//        String s = "[it was]Saturday {afternoon (and) we} cooked (meal outside)"; //Correct
//        String s = "[it was]Saturday {afternoon (and} we) cooked (meal outside)"; //Incorrect

//        In above strings, first one opens and closes the brackets in correct order and the second one opens and closes brackets in incorrect order,
//        write a code/method which takes a bracketed string as input (could be any string) and returns true if brackets are balanced, false  if brackets are imbalanced.

        Stack<Character> stack = new Stack<>();
        boolean status = true;
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)=='[' || s.charAt(i)=='{' || s.charAt(i)== '('){
                stack.push(s.charAt(i));
                continue;
            }
            if(s.charAt(i)==')'){
                if(stack.peek()=='('){
                    stack.pop();
                }else{
                    status = false;
                    break;
                }
            }
            else if(s.charAt(i)=='}'){
                if(stack.peek()=='{'){
                    stack.pop();
                }else{
                    status = false;
                    break;
                }
            }
            else if(s.charAt(i)==']'){
                if(stack.peek()=='['){
                    stack.pop();
                }else{
                    status = false;
                    break;
                }
            }

        }
        if(status)
            System.out.println("balanced");
        else
            System.out.println("not balanced");

    }
}
