package leetcode.interview;

public class Boeing_2 {
    public static void main(String[] args) {
        printDivisibleNumber(1,20);
        fibonnaciSeries(6);
    }


    /**
     * write a program to print 'Naveen' if the number is divisble by 3, 'Titu' if divisible by 5 and 'Titu and Naveen' if divisible by 3 and 5 both.
     * If it is not satisfying these three conditions, then print the number
     * @param x is start of the number
     * @param y is end of the number
     */
    public static void printDivisibleNumber(int x, int y){
        boolean naveen = false;
        boolean titu = false;
        boolean both = false;
        for(;x<=y; x++){
            if(x%3==0){
                naveen = true;
            }
            if(x%5 == 0){
                titu = true;
                if(naveen)
                    both = true;
            }
            if(both){
                System.out.println("Naveen and Titu");
                naveen = false;
                titu = false;
                both = false;
                continue;
            }
            if(naveen)
                System.out.println("Naveen");
            else if(titu)
                System.out.println("Titu");
            else
                System.out.println("printing number not divisible by 3 or 5 or both 3&5 -  "+ x);
            naveen = false;
            titu = false;
            both = false;
        }
    }

    /**
     * write a program to return the value at length of a fibonnaci series
     * @param number at this point return the value from array
     */
    public static void fibonnaciSeries(int number){
        int first = 0;
        int second = 1;
//        System.out.println(first);
//        System.out.println(second);
        int nextnumber = 0;
        for(int i=2; i<=number; i++){
            nextnumber = first+second;
//            System.out.println(nextnumber);
            first = second;
            second = nextnumber;
        }
        System.out.println("when user enter - "+number+ " -> then at this index the value in fibbonci series is - "+nextnumber);
    }

}
