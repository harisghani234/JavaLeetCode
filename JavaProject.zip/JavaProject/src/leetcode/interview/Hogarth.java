package leetcode.interview;

public class Hogarth {
    public static void main(String[] args)
    {
        // write a program to sort array in ascending order for only values which are odd and even should be as it is
        int [] inputArray = {5, 3, 2, 8, 1, 4};
        // expected output = [1, 3, 2, 8, 5, 4]
        for(int i=0; i<inputArray.length; i++){
            if(inputArray[i]%2==0){
                continue;
            }
            for(int j =i+1;j<inputArray.length;j++){
                if(inputArray[j]%2 != 0) {
                    if(inputArray[i]>inputArray[j]){
                        int temp = inputArray[i];
                        inputArray[i] = inputArray[j];
                        inputArray[j] = temp;
                    }
                }
            }
        }

        for(int i =0; i<inputArray.length;i++){
            System.out.print(inputArray[i]+ ", ");
        }
    }
}
