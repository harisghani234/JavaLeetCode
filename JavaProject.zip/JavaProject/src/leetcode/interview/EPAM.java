package leetcode.interview;

import java.util.Arrays;

public class EPAM {
    // move all 0 to end of array and order of insertion for non-zero number should be preserved
    public static void main(String[] args) {
        int[] arr = {0, 0, 1, 0, 3, 12, 4, 6, 87, 0, 7, 0};
        int temp =0;
        for(int i=0; i<arr.length; i++){
            if(arr[i]!=0){
                arr[temp++] = arr[i];
            }
        }
        System.out.println(Arrays.toString(arr));
        for(int i=temp; i<arr.length; i++){
            arr[i]=0;
        }
        System.out.println(Arrays.toString(arr));

    }
}
