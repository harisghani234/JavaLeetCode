package leetcode.interview;

public class Nykaa_2 {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
