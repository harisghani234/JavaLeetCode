package leetcode.interview;

public class Syncechron_L2 {
    public static void main(String[] args) {
        String str = "This is a test string";
        String [] array = str.split(" ");
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<array.length; i++){
            sb.append(array[i]);
        }
        System.out.println(sb);
        int rotation = 4;
        int pointer = 0;
        StringBuilder output = new StringBuilder();
        while(pointer<rotation){
            char c = sb.charAt(sb.length()-1-pointer);
            output.append(c);
            pointer++;
        }
        output = output.reverse();
            output.append(sb.substring(0,sb.length()-rotation)); // we can use the above commented line as well

        System.out.println(output);

    }
}
