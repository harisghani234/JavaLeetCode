package leetcode.interview;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;
// write a program to remove all the elements which are duplicate and keep the first occurance.
public class Zuchitech {
    public static void main(String[] args) {
        String s = "selenieums";
        usingSet(s);
        usingMap(s);
        usingIntArray(s);

    }

    public static void usingSet(String s){
        StringBuffer output = new StringBuffer();
        Set<Character> set = new TreeSet<>();
        for(int i=0;i<s.length();i++){
            if(set.add(s.charAt(i))==true){
                output.append(s.charAt(i));
            }
        }
        System.out.println(output);
    }

    public static void usingMap(String s){
        StringBuffer sb = new StringBuffer();
        HashMap<Character, Integer> hmap = new HashMap<>();
        for(int i=0; i<s.length(); i++){
            if(hmap.containsKey(s.charAt(i))){

            }else{
                hmap.put(s.charAt(i),1);
                sb.append(s.charAt(i));
            }
        }
        System.out.println(sb);
    }

    public static void usingIntArray(String s){
        StringBuffer sb = new StringBuffer();
        int [] arr= new int[26];
        for(int i=0; i<s.length(); i++){
            int index = s.charAt(i)-'a';
            if(arr[index]==1)
                arr[index]= 1;
            else
                arr[index]=1;
        }
        for(int i=0; i<s.length(); i++){
            int index = s.charAt(i)-'a';
            if(arr[index]==1) {
                sb.append(s.charAt(i));
                arr[index]=0;
            }

        }
        System.out.println(sb);
    }


}
