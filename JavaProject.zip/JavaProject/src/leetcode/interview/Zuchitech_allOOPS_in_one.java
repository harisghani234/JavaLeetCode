package leetcode.interview;

public class Zuchitech_allOOPS_in_one {
    public static void main(String[] args) {
        // Encapsulation example
        Person person = new Person("Alice", 30);
        person.displayInfo();

        // Inheritance example
        Student student = new Student("Bob", 20, 101);
        student.displayInfo();

        // Polymorphism example
        Shape shape1 = new Circle();
        shape1.draw();

        Shape shape2 = new Rectangle();
        shape2.draw();

        // Abstraction example
        Animal dog = new Dog();
        dog.makeSound();
    }
}


// Encapsulation: Class encapsulates the data (fields) and methods to operate on the data
class Person {
    private String name;
    private int age;

    // Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter and setter methods to access and modify private fields
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Method to display person information
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

// Inheritance: Subclass inherits properties and behaviors from the superclass
class Student extends Person {
    private int rollNumber;

    // Constructor
    public Student(String name, int age, int rollNumber) {
        super(name, age); // Call superclass constructor
        this.rollNumber = rollNumber;
    }

    // Method to display student information
    @Override
    public void displayInfo() {
        super.displayInfo(); // Call superclass method
        System.out.println("Roll Number: " + rollNumber);
    }
}

// Polymorphism: Same method name but different implementations in subclasses
class Shape {
    public void draw() {
        System.out.println("Drawing a shape");
    }
}

class Circle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a circle");
    }
}

class Rectangle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a rectangle");
    }
}

// Abstraction: Hiding the implementation details and showing only essential features of the object
abstract class Animal {
    // Abstract method (no implementation)
    public abstract void makeSound();
}

class Dog extends Animal {
    // Implementing abstract method
    @Override
    public void makeSound() {
        System.out.println("Woof!");
    }
}

//public class Main {
//    public static void main(String[] args) {
//        // Encapsulation example
//        Person person = new Person("Alice", 30);
//        person.displayInfo();
//
//        // Inheritance example
//        Student student = new Student("Bob", 20, 101);
//        student.displayInfo();
//
//        // Polymorphism example
//        Shape shape1 = new Circle();
//        shape1.draw();
//
//        Shape shape2 = new Rectangle();
//        shape2.draw();
//
//        // Abstraction example
//        Animal dog = new Dog();
//        dog.makeSound();
//    }
//}

