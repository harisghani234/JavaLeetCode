package leetcode.interview;

public class Test {
    public static void main(String[] args) {
        String s = "aaabbaabbcc";
        int c = s.charAt(0);
        int count =0;
        String output = s.charAt(0)+"";
        for( int i=0; i<s.length();i++){
            if(s.charAt(i)==c){
                count++;
            }else{
                output = output+s.charAt(i)+count;
                c=s.charAt(i);
                count=1;
            }
        }
        System.out.println(output);
    }
}
