package interview;

public class Apple {
    public static void main(String[] args) {
        String input = "aaaabbaacccdee";
        System.out.println(compressString(input));
        System.out.println(method(input)); // working


    }

    public static String compressString(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        String output = "";
        int count = 1;
        char current_char = input.charAt(0);
        for (int i = 1; i < input.length(); i++) {
            if (input.charAt(i) == current_char) {
                count++;
            } else {
                output=output+current_char+count;
                current_char=input.charAt(i);
                count=1;
            }
            if(i == input.length()-1){
                output=output+current_char+count;
            }
        }

        return output;
    }

    public static String asciiValue(String input){
        String output = "";
        int [] arr = new int[26];
        char c = input.charAt(0);
        for(int i=0; i<input.length(); i++){
            int index = input.charAt(i)-'a';
            arr[index]= arr[index]+1;
            System.out.println(arr[index]);
            if(c!=input.charAt(i)){
                output = output + c + arr[c-'a'];
                arr[index] = 0;
                c = input.charAt(i);
            }
        }
        System.out.println(output);
        return output;
    }

    public static String method(String input){
        String output = "";
        char c = input.charAt(0);
        int count = 0;
        for(int i=0; i<input.length();i++){
            if(c==input.charAt(i)){
                count++;
                if(i==input.length()-1){
                    output = output+c+count;
                }
            }else{
                output = output+c+count;
                c = input.charAt(i);
                count=1;
            }
        }
        return  output;
    }



}
