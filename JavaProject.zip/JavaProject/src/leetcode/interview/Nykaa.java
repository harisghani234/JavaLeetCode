package leetcode.interview;

import java.util.Stack;

public class Nykaa {
    public static void main(String[] args) {
       String s = "[]){}()";
       boolean result = true;
        Stack<Character> stack = new Stack<>();
       for(int i=0; i<s.length(); i++){
           if(s.charAt(i)=='[' || s.charAt(i) == '(' || s.charAt(i) == '{'){
               stack.push(s.charAt(i));
           }else{
               if(s.charAt(i)==']' && stack.size()!=0){
                   if(stack.peek()=='['){
                       stack.pop();
                   }else{
                       result = false;
                       break;
                   }
               }
               else if(s.charAt(i)==')' && stack.size()!=0){
                   if(stack.peek()=='('){
                       stack.pop();
                   }else{
                       result = false;
                       break;
                   }
               }
               else if(s.charAt(i)=='}' && stack.size()!=0){
                   if(stack.peek()=='{'){
                       stack.pop();
                   }else{
                       result = false;
                       break;
                   }
               }else{
                   result = false;
                   break;
               }

           }
       }

       if(result)
           System.out.println("balanced"    );
       else
           System.out.println("Not balanced");



    }
}
