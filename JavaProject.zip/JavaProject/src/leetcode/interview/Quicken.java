package leetcode.interview;

import java.util.HashMap;
import java.util.Map;

public class Quicken {
    public static void main(String[] args) {

    //        i/p: {a, b, c, c, a, b}
    //        o/p: YES
    //
    //        i/p: {a, c, b, c, a, e}
    //        o/p: NO
    //
    //        i/p: {a, d, d, e, g, a, g}
    //        o/p: YES

//        char[] input = {'a', 'b', 'c', 'c', 'a', 'b'};
//        char[] input = {'a', 'c', 'b', 'c', 'a', 'e'};
        char[] input = {'a', 'd', 'd', 'e', 'g', 'a', 'g'};
        boolean status = true;
        HashMap<Character, Integer> hmap = new HashMap<>();
        for(int i=0; i<input.length; i++){
            if(hmap.containsKey(input[i]))
                hmap.put(input[i],hmap.get(input[i])+1);
            else
                hmap.put(input[i],1);
        }
        if(input.length%2==0){
            // even and every key should be %2=0
            for(Map.Entry<Character, Integer> i : hmap.entrySet()){
                if(i.getValue()%2!=0){
                    status = false;
                    break;
                }
            }
        }else{
            int allowed =0;
            for(Map.Entry<Character, Integer> i : hmap.entrySet()){
                if(i.getValue()%2==0){

                }else{
                    allowed=allowed+1;
                    if(allowed>1){
                        status=false;
                        break;
                    }
                }

            }
        }



        if(status)
            System.out.println("True");
        else
            System.out.println("false");

    }
}
