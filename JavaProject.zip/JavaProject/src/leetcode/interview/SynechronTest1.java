package leetcode.interview;

import java.util.*;

public class SynechronTest1 {
    public static void main(String[] args) {
//       listMethod();
    setMethod();

    }

    public static void listMethod(){
        // remove all the duplicate values from list
        int no = 10;
        List<String> li = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        for (int i=0;i<no ; i++){
            li.add(sc.nextLine());
        }

        for(String val : li){
            System.out.println(val);
        }
    }

    public static void setMethod(){
        Set<String> set = new HashSet<>();
        int no = 10;
        Scanner sc = new Scanner(System.in);
        for(int i=0; i<no; i++){
            String s = sc.nextLine();
            set.add(s);
        }
        for(String s: set){
            System.out.println(s);
        }

    }

}
