package leetcode.interview;

import java.util.HashMap;
import java.util.Map;

public class GlobalLogic {
    public static void main(String[] args) {
        int [] arr = {43,5,2,100,24,43,67,34,67};

        for(int i=0; i<arr.length; i++){
            boolean isUnique=true;
            for(int j=i+1; j<arr.length; j++){
                if(arr[i]==arr[j]){
                    isUnique = false;
                    break;
                }
            }
            if(isUnique){
                System.out.println("Unique "+arr[i]);
            }else{
                System.out.println("not unique"+ arr[i]);
            }
        }




    }
}

