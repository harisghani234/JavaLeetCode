package leetcode.interview;

import java.util.HashMap;

public class Zuchitech_2 {
    public static void main(String[] args) {
        String s = "seleniumms";
        usingIntArrayConcept(s);
        usingHashMap(s);

    }

    public static void usingIntArrayConcept(String s){
        StringBuffer sb = new StringBuffer();
        int [] arr = new int[26];
        for(int i = 0; i<s.length(); i++){
            int index = s.charAt(i)-'a';
            arr[index]=arr[index]+1;
        }
        for(int i=0; i<s.length(); i++){
            int index = s.charAt(i)-'a';
            if(arr[index]==1){
                sb.append(s.charAt(i));
            }
        }
        System.out.println(sb);
    }

    public static void usingHashMap(String s){
        StringBuffer sb = new StringBuffer();
        HashMap<Character, Integer> hmap = new HashMap<>();
        for(int i=0; i<s.length(); i++){
            if(hmap.containsKey(s.charAt(i)))
                hmap.put(s.charAt(i),hmap.get(s.charAt(i))+1);
            else
                hmap.put(s.charAt(i),1);
        }
        for(int i=0; i<s.length();i++){
            if(hmap.containsKey(s.charAt(i))&& hmap.get(s.charAt(i))==1){
                sb.append(s.charAt(i));
            }
        }
        System.out.println(sb);
    }

}
