package leetcode.interview;

import java.util.ArrayList;
import java.util.List;

public class PayPaY {
    public static void main(String[] args) {
//        String s = "ABCDDEfghCBAB";
//      String s = "A";
//        String s = "BA";
        String s = "BAAAA";
//        String s = "BA";
//        String s = "BA";
//        String s = "BA";


        System.out.println(method(s));


    }

    public static List<String> method(String s){
        int l = 0;
        ArrayList<String> al = new ArrayList<>();
        if(s.length() == 1){
            al.add(s);
            return al;
        }
        if(s.isEmpty()){
            return al;
        }
        for(int i =0; i<s.length()-1; i++){
            if(s.charAt(i+1)-s.charAt(i)==1){
                //ignoring this block
            }else{
                String res = s.substring(l,i+1);
                l=i+1;
                al.add(res);
            }
            if(i==s.length()-2){
                String res = s.substring(l,i+2);
                al.add(res);
            }
        }
        return al;
    }
}
