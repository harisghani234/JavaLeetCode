package leetcode;

import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
       String s = "Let's take LeetCode contest";

        test(s);
    }

    public static void test(String s){
        String [] arr = s.split(" ");
        String output = " ";
       for(int i=0; i<arr.length; i++){
            for (int j=arr[i].length()-1; j>=0; j--){
                output = output +arr[i].charAt(j);
            }
            output = output+" ";
       }
        System.out.println(output.trim());
    }
}
