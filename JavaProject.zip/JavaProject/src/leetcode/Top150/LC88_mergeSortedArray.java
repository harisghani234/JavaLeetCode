package leetcode.Top150;

import java.util.Arrays;

public class LC88_mergeSortedArray {
//    Write a Java  program to reverse each word in a given string?
//
//    Input: Welcome to interview
//
//    Output: emoclew ot weivretni

    public static void main(String[] args) {
        int[] a = {1, 3, 5, 9, 12, 15};
        int[] b = {2, 4, 7, 8};
        int[] output = new int[a.length + b.length];
        int l = 0;
        int r = 0;
        int k = 0;
        while (l < a.length && r < b.length) {
            if (a[l] >= b[r]) {
                output[k++] = b[r];
                r++;
            } else {
                output[k++] = a[l];
                l++;
            }
        }
        while(l<a.length){
            output[k++] = a[l++];
        }
        while (r<b.length){
            output[k++] = b[r++];
        }
        System.out.println(Arrays.toString(output));

    }

}


