package leetcode.Top150;

import java.util.Arrays;

public class LC88_mergeSortedArray {
//    Write a Java  program to reverse each word in a given string?
//
//    Input: Welcome to interview
//
//    Output: emoclew ot weivretni

    public static void main(String[] args) {
        String input = "Welcome to interview";
        String [] inputArray = input.split(" ");
        for(int i=0; i<inputArray.length; i++){
//            String word = inputArray[i];
            for(int j=inputArray[i].length()-1; j>=0; j--){
                System.out.print(inputArray[i].charAt(j));
            }
            System.out.print(" ");
        }
    }

}


