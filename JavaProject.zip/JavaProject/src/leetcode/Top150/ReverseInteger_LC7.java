package leetcode.Top150;

public class ReverseInteger_LC7 {
    public static void main(String[] args) {
//        int n = -123;
        int n =1534236469;
        System.out.println(reverse(n));
    }

    public static int reverse(int x) {
        String s = String.valueOf(x);
        if(s.length()>6){
            return 0;
        }
        int reverse = 0;
        int temp = x;
        if(x<0){
            temp = -x;
        }
        while(temp>0){
            int rem = temp % 10;
            reverse = reverse*10 + rem;
            temp = temp/10;
        }
        if(x<0)
            return -reverse;
        return reverse;
    }
}
