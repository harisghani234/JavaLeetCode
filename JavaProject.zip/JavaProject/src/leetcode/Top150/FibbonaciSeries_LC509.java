package leetcode.Top150;

import java.util.ArrayList;

public class FibbonaciSeries_LC509 {
    public static void main(String[] args) {
        int n = 5;
        System.out.println(fib_withoutDS(n));
        System.out.println(fib_withArrayList(n));


    }

    public static int fib_withoutDS (int n) {
        if(n==0)
            return 0;
        int f1 = 0;
        int f2 = 1;
        if(n==1)
            return f1+f2;
        if(n==2)
            return f1+f2;
        int sum =0;
        for (int i=0; i<n-2; i++){
            int f3 = f1+f2;
            f1 = f2;
            f2 = f3;
            if(i==n-3){
                sum = f1+f2;
            }
        }
        return sum;

    }

    public static int fib_withArrayList(int n){
        int f1 = 0;
        int f2 = 1;
        ArrayList<Integer> al = new ArrayList<>();
        if (n==0)
            return 0;
        if(n==1 || n == 2)
            return f1+f2;
        for(int i=0; i<n-2; i++){
            int f3 = f1+f2;
            al.add(f3);
            f1=f2;
            f2=f3;
        }
        return al.get(al.size()-1)+al.get(al.size()-2);
    }

}
