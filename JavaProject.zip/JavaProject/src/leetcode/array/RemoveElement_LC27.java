package leetcode.array;

import java.util.Arrays;

public class RemoveElement_LC27 {
    public static void main(String[] args) {
        int [] arr = {3,2,2,3};
        int val = 3;
        removeElement(arr,val);

    }
    public static int removeElement(int[] nums, int val){
        int start = 0;
        int end = nums.length-1;
        while(start<=end){
            if(start!=val){
                start++;
                continue;
            }
            if(end==val){
                end--;
                continue;
            }
            if(start==val && end!=val){
                nums[start]=nums[end];
                nums[end]=val;
                start++;
            }
        }
        System.out.println(Arrays.toString(nums));
        System.out.println(start);
        return start;
    }
}
