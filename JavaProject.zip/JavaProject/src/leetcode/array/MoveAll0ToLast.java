package leetcode.array;

import java.util.Arrays;

public class MoveAll0ToLast {

    public static void main(String[] args) {

        int a[] = {0, 1, 0, 3, 12}; // [1,3,12,0,0]
//        int a []= {0}; // [0]
//        orderNotPreseved(a);

         preserveOrder(a);
    }

    public static void orderNotPreseved(int [] a){
        int l=0;
        int r = a.length-1;
        while(l<r){
            if(a[l]==0 && a[r]!=0){
                a[l]=a[r];
                a[r]=0;
            }
            if(a[l]!=0){
                l++;
                continue;
            }
            if(a[r]==0){
                r--;
            }
        }
        System.out.println(Arrays.toString(a));
    }

    public static void preserveOrder(int [] a){
        int temp =0;
        int totalzero=0;
        for(int i=0;i<a.length;i++){
            if(a[i]!=0)
                a[temp++]=a[i];
            else
                totalzero++;
        }
        for(int i=a.length-1;i>totalzero;i--){
            a[i]=0;
        }

        System.out.println(Arrays.toString(a));

    }
}
