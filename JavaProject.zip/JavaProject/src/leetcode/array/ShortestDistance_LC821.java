package leetcode.array;

public class ShortestDistance_LC821 {
    public static void main(String[] args) {
        String s = "baaa";
        char c = 'b';
        System.out.println(shortestToChar(s, c));

    }

    public static int[] shortestToChar(String s, char c) {
        {
            int a[] = new int[s.length()];
            int p1 =0, p2 = 0, k = 0;
            int leftSideVal = 0;
            int rightSideValue = 0;

            for(int i =0; i<s.length();i++){
                if(s.charAt(i) == c){
                    a[k++] = 0;
                    leftSideVal = 0;
                    rightSideValue = 0;
                    p1=i+1;
                    p2 = i+1;
                    continue;
                }
                while(p1>=0){
                    if(p1 <= 0 && c == s.charAt(p1)){
                       leftSideVal = i-p1;
                       break;
                    }
                    if(p1 <= 0){
                        leftSideVal = 100000;
                        break;
                    }
                    if(s.charAt(p1) != c){
                        p1--;
                    }else{
                        leftSideVal = i-p1;
                        p1 = i+1;
                        break;
                    }
                }
                System.out.println("left side value for "+ i + " is - "+leftSideVal);
                while(p2<=s.length()){
                    if(p2 >= s.length()){
                        rightSideValue = 100000;
                        break;
                    }
                    if(s.charAt(p2)!= c){
                        p2++;
                    }else{
                        rightSideValue = p2-i;
                        p2 = i+1;
                        break;
                    }
                }
                System.out.println("Right side value for "+ i + " is - "+rightSideValue);
                if(rightSideValue>leftSideVal){
                    a[k++] = leftSideVal;
                }else {
                    a[k++] = rightSideValue;
                }
                leftSideVal = 0;
                rightSideValue = 0;
            }

            for(int n:a){
                System.out.print(n+",");
            }
            return a;
        }
    }
}
