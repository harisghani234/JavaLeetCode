package leetcode.array;

import java.util.Arrays;

public class BoatToSavePeople {
    public static void main(String[] args) {

        int [] people = {3,5,3,4};
        int limit = 5;
        System.out.println(numRescueBoats(people, limit));
    }

    public static int numRescueBoats(int[] people, int limit) {
        int totalBoats = 0;
        Arrays.sort(people);
        int i =0;
        int j = 1;
        while(i<people.length && j<people.length){
            if(people[i] == limit){
                totalBoats++;
                i++;
                j++;
            }else if(people[i]<limit){
                if(people[i]+people[j] <= limit){
                    totalBoats++;
                    i = j+1;
                    j++;
                }else{
                    totalBoats++;
                    i++;
                    j++;
                }
            }else{
                break;
            }
        }


        return totalBoats;

    }
}

