package leetcode.array;

import java.util.HashMap;

public class MaxNumberKSum_LC1679 {
    public static void main(String[] args) {
        int [] nums = {3,5,1,5};
        int k = 2;
        System.out.println(maxOperations(nums, k));
    }

    public static int maxOperations(int[] nums, int k) {
        HashMap<Integer, Integer> hmap = new HashMap<>();
        int output =0;
        for(int i =0; i<nums.length;i++){
            if(hmap.containsKey(nums[i]))
                hmap.put(nums[i],hmap.get(nums[i])+1);
            else
                hmap.put(nums[i],1);
        }
        for(int i=0; i<nums.length; i++){
            int findValue = k-nums[i];
            if(hmap.containsKey(findValue) && hmap.get(nums[i])>0 && hmap.get(findValue)>0){
                output = output+1;
                if(findValue == nums[i] && hmap.get(nums[i])==1){
                    output = output-1;
                }
                hmap.put(nums[i], hmap.get(nums[i])-1);
                hmap.put(findValue, hmap.get(findValue)-1);

                if(findValue == nums[i] && hmap.get(nums[i])%2!=0){
                    hmap.put(nums[i], hmap.get(nums[i])-1);
                }



            }
        }
        return output;
    }
}
