package leetcode.array;

import java.lang.reflect.Array;
import java.util.Arrays;

public class LeftRightSumDifference_LC2574 {
    public static void main(String[] args) {
        /**Input: nums = [10,4,8,3]
        Output: [15,1,11,22]
        Explanation: The array leftSum is [0,10,14,22] and the array rightSum is [15,11,3,0].
        The array answer is [|0 - 15|,|10 - 11|,|14 - 3|,|22 - 0|] = [15,1,11,22].Input: nums = [10,4,8,3]
        Output: [15,1,11,22]
        Explanation: The array leftSum is [0,10,14,22] and the array rightSum is [15,11,3,0].
        The array answer is [|0 - 15|,|10 - 11|,|14 - 3|,|22 - 0|] = [15,1,11,22].
         **/
        int[] input = {10,4,8,3};
        leftRightDifference(input);
    }

    public static int[] leftRightDifference(int[] nums) {
        int [] leftArray = new int[nums.length];
        int [] rightArray = new int[nums.length];
        int [] outputArray = new int[nums.length];
        int lSum = 0;
        int rSum = 0;
        leftArray[0] = lSum;
        rightArray[nums.length-1] = rSum;
        for(int i=1; i<nums.length; i++){
            leftArray[i]= lSum + nums[i-1];
            lSum = leftArray[i];
        }
        for(int i=nums.length-2; i>=0; i--){
            rightArray[i]= rSum + nums[i+1];
            rSum = rightArray[i];
        }
        for(int i=0; i<leftArray.length; i++){
            outputArray[i] = leftArray[i] - rightArray[i];
            if(outputArray[i] < 0){
                outputArray[i] = -outputArray[i];
            }
        }
        return outputArray;
    }
}
