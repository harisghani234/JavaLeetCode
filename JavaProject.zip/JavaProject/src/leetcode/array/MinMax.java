package leetcode.array;

public class MinMax {
    public static void main(String[] args) {
        int a[]={1,423,6,46,34,23,13,53,4};
        int min = a[0];
        int max = a[0];
        for(int i=0;i<a.length;i++){
            if(a[i]>=max) {
                max = a[i];
                continue;
            }
            if(a[i]<=min) {
                min = a[i];
            }
        }
        System.out.println(min);
        System.out.println(max);
    }
}
