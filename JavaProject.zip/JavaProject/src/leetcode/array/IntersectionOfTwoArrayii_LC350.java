package leetcode.array;

import java.sql.PreparedStatement;
import java.util.*;

public class IntersectionOfTwoArrayii_LC350 {
    public static void main(String[] args) {
        int[] nums1 = {4,9,5};
        int [] nums2 = {9,4,9,8,4};
//        int[] nums1 = {1,2,2,1};
//        int [] nums2 = {2,2};

        int [] result = intersection(nums1, nums2);
        for(int val : result){
            System.out.println(val);
        }
    }

    /**
     * using hashmap and set
     * @param nums1
     * @param nums2
     * @return
     */
    public static int[] intersection(int[] nums1, int[] nums2) {
        HashMap<Integer, Integer> hmap = new HashMap<>();
        List<Integer> li = new ArrayList<>();
        for(int val1:nums1){
            if(!hmap.containsKey(val1)){
                hmap.put(val1,1);
            }else{
                hmap.put(val1, hmap.get(val1)+1);
            }
        }
        for(int val2:nums2){
            if(hmap.containsKey(val2) && hmap.get(val2)>=1){
                hmap.put(val2, hmap.get(val2)-1);
                li.add(val2);
            }
        }
        int [] result = new int[li.size()];
        int i =0;
        for(int res: li){
            result[i++] = res;
        }
        return result;
    }

}
