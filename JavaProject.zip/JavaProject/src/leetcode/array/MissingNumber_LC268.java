package leetcode.array;

import java.util.Arrays;

public class MissingNumber_LC268 {
    public static void main(String[] args) {
        int [] nums = {1};
        System.out.println(missingNumber(nums));
    }

    public static int missingNumber(int[] nums) {
        int n = 0;
        boolean [] arr = new boolean[nums.length];
        try {
            for(int i=0; i<nums.length; i++){
                arr[nums[i]] = true;
            }
        }
        catch (Exception StringIndexOutOfBoundsException){
            System.out.println("Ignoring adding this field");
        }
        for(int i = 0; i<arr.length; i++){
            if(!arr[i]){
                n=i;
            }
        }
        if(n==0){
            System.out.println("all worked");
            return nums.length;
        }

        return n;
    }
}
