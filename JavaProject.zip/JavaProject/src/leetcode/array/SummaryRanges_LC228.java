package leetcode.array;

import java.util.*;

public class SummaryRanges_LC228 {
    public static void main(String[] args) {
        int[] nums = {0, 2, 4, 5, 7};
        //["0->2","4->5","7"]

        List<String> li = summaryRanges(nums);
        for (String s : li) {
            System.out.println(s);
        }


    }

    public static List<String> summaryRanges(int[] nums) {
        List<String> li = new ArrayList<>();
        if(nums.length == 1){
            li.add(Integer.toString(nums[0]));
            return li;
        }
        int indexLeft = 0;
        for (int i = 1; i < nums.length; i++) {
            if (nums[i - 1] + 1 == nums[i]) {
            } else {
                if (nums[indexLeft] == nums[i - 1]) {
                    li.add(Integer.toString(nums[i - 1]));
                } else {
                    String s = Integer.toString(nums[indexLeft]) + "->" + Integer.toString(nums[i - 1]);
                    li.add(s);
                }
                indexLeft = i;
            }
            if (i == nums.length - 1) {
                if (nums[indexLeft] == nums[i]) {
                    li.add(Integer.toString(nums[i]));
                } else {
                    String s = Integer.toString(nums[indexLeft]) + "->" + Integer.toString(nums[i]);
                    System.out.println("hsadfa" + s);
                    li.add(s);
                }
            }
        }

        return li;

    }
}
