package leetcode.array;

import java.util.*;

public class RemoveDuplicate_LC26 {
    public static void main(String[] args) {
        int[] input = {0,0,0,1,  1, 2, 2, 3, 3,4, 4,4};
//        removeDuplicates(input);
//        removeDuplicateWithApproach2(input);
        removeDuplicateWithApproach3(input);

    }

    /*
    program using maptree as hashmap does not store the values in insertion order and we dont have to bother about values after unique is updated
     */
    public static int removeDuplicates(int[] nums) {
        TreeMap<Integer, Integer> hmap = new TreeMap<>();
        for (int i = 0; i < nums.length; i++) {
            if (hmap.containsKey(nums[i]))
                hmap.put(nums[i], hmap.get(nums[i]));
            else
                hmap.put(nums[i], 1);
        }
        int i = 0;
        for (Map.Entry<Integer, Integer> map : hmap.entrySet()) {
            nums[i++] = map.getKey();
        }
        System.out.println(Arrays.toString(nums));
        return i;
    }

    public static int removeDuplicateWithApproach2(int[] nums) {
        int count = 1;
        for (int i = 1; i < nums.length; i++) {
            if (nums[i - 1] != nums[i]) {
                nums[count++] = nums[i];
            }
        }
        System.out.println(Arrays.toString(nums));
        return count;
    }

    public static int removeDuplicateWithApproach3(int[] nums) {
        int count = 0;
        for (int i = 0; i < nums.length-1; i++) {
            if (nums[i] != nums[i + 1]){
                nums[count++]=nums[i];
            }
        }
        nums[count++] = nums[nums.length-1];
        System.out.println(Arrays.toString(nums));
        return count;
    }


}
