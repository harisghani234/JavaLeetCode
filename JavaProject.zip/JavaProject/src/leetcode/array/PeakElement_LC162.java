package leetcode.array;

public class PeakElement_LC162 {
    public static void main(String[] args) {
        int [] nums = {2,1};
        System.out.println(findPeakElement(nums));
    }
    public static int findPeakElement(int[] nums){
        int maxElement = nums[0];
        if(nums.length ==1){
            return 0;
        }
        for(int i=1;i<nums.length;i++) {
            int leftVal = i - 1;
            int rightVal = i + 1;
            if(i==nums.length-1){
                if(maxElement<nums[i])
                    maxElement = nums[i];
                break;
            }
            if(maxElement<nums[i])
                maxElement = nums[i];
            if(nums[i]>nums[leftVal] && nums[i]>nums[rightVal]){
                System.out.println("Peak is found and it is - "+nums[i]);
                return i;
            }
        }
        if(nums[0]==maxElement)
            return 0;
        else if(nums[nums.length-1] == maxElement)
            return nums.length-1;
        else
            return -1;


    }

}
