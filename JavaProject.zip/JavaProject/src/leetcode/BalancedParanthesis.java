package leetcode;

import java.util.Stack;

public class BalancedParanthesis {
    public static void main(String[] args) {
//        String input = "]";
        String input = "[()]{}{[()()]()}";
//        boolean output = checkValidParanthesis(input);
        boolean output = checkValidParanthesis2(input);
        if (output == true) {
            System.out.println("Valid parenthesis");
        } else {
            System.out.println("Invalid parenthesis");
        }

    }

    // this approach is taking much more time than the below approach like 8ms whereas the below one is taking 2ms
    public static boolean checkValidParanthesis(String s) {
        if (s.length() == 0) {
            return false;
        }
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '(' || s.charAt(i) == '{' || s.charAt(i) == '[') {
                stack.push(s.charAt(i));
//                System.out.println(stack);
            } else if (stack.size() != 0 && s.charAt(i) == ')') {
                if (stack.peek() == '(') {
                    stack.pop();
                } else {
                    return false;
                }
            } else if (stack.size() != 0 && s.charAt(i) == ']') {
                if (stack.peek() == '[') {
                    stack.pop();
                } else {
                    return false;
                }
            } else if (stack.size() != 0 && s.charAt(i) == '}') {
                if (stack.peek() == '{') {
                    stack.pop();
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
        if (stack.size() != 0) {
            return false;
        }
        return true;
    }

    public static boolean checkValidParanthesis2(String s) {
        if (s.length() == 0) {
            return false;
        }
        Stack<Character> stack = new Stack<>();
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)=='['||s.charAt(i)=='{'||s.charAt(i)=='('){
                stack.push(s.charAt(i));
            }
            else if(stack.size()==0){
                return false;
            }
            else if(s.charAt(i)==')'){
                if(stack.size()!=0 && stack.pop()!='('){
                    return false;
                }
            }
            else if(s.charAt(i)==']'){
                if(stack.size()!=0 && stack.pop()!='['){
                    return false;
                }
            }
            else if(s.charAt(i)=='}'){
                if(stack.size()!=0 && stack.pop()!='{'){
                    return false;
                }
            }
        }
        return true;
    }

}
