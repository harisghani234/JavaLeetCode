package leetcode;

public class AllSubsequence {
    public static void main(String[] args) {
        String input = "abc";
        subsequence(input, "", 0);
    }

    public static void subsequence(String input, String output, int index) {
        // base class when to exit
        if(index >= input.length()){
            System.out.println(output);
            return;
        }
        output = output+input.charAt(index);
        subsequence(input, output, index+1);

        output = output.substring(0, output.length()-1);
        subsequence(input, output, index+1);
    }
}
