package basics;

import javax.sound.midi.Soundbank;
import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Sample {
    public static void main(String[] args) {
        String s = "aabbbccca";
        removeCharacterFromString(s);

    }

    /*
        this function will find the longest palindrome and print
     */
    public static void removeCharacterFromString(String s){
        HashMap<Character, Integer> hm = new HashMap<>();
        for(int i=0;i<s.length();i++){
            if(hm.containsKey(s.charAt(i)))
                hm.put(s.charAt(i),hm.get(s.charAt(i))+1);
            else
                hm.put(s.charAt(i),1);
        }

        System.out.println(hm);
        // check which value is max;
        int max = 0;
        ArrayList<Character> al = new ArrayList<>();
        for(Map.Entry<Character, Integer> i: hm.entrySet()){
            if(i.getValue()>max){
                max = i.getValue();
                al.removeAll(al);
                al.add(i.getKey());
            }else if(i.getValue()==max){
                al.add(i.getKey());
            }
        }
        System.out.println(al);
    }

}
