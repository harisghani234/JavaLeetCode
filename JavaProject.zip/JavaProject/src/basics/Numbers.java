package basics;

public class Numbers {
    public static void main(String[] args) {
//        swapNumber(10,20);
        reverseNumber(12345);
    }

    public static void swapNumber(int a, int b){
        int sum = a+b;
        a = sum-a;
        b = sum-b;
        System.out.println(a);
        System.out.println(b);
    }
    public static void reverseNumber(int num){
        int output = 0;
        while (num>0){
            int rem = num%10;
            output=output*10+rem;
            num=num/10;
        }
        System.out.println(output);

    }

    public static void palindromeNumber(int num){

    }

}
