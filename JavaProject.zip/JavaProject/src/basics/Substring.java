package basics;

import java.util.ArrayList;
import java.util.Arrays;

public class Substring {
    public static void main(String[] args) {
        String s = "sunil";
        findsubstring(s);

    }

    public static void findsubstring(String s){
        String output = "";
        ArrayList<String> al = new ArrayList<>();
        for(int i=0;i<s.length();i++){
            for(int j=i;j<s.length();j++){
                output = output+s.charAt(j);
                al.add(output);
            }
            output="";
        }
        System.out.println(al);
        ArrayList<String> al2 = new ArrayList<>();
        for(int i=0;i<al.size();i++){
           boolean result =  findPalindrome(al.get(i));
           if(result) {
               System.out.println("palindrome - " + al.get(i));
               al2.add(al.get(i)); // find the string with length largeset
                }
           else{
                   System.out.println("Not Palindrome - " + al.get(i));
               }
        }
    }

    public static boolean findPalindrome(String s){
        int l=0, r=s.length()-1;
        while(l<r){
            if(s.charAt(l)==s.charAt(r)) {
                l++;
                r--;
            }else{
                return false;
            }
        }
        return true;
    }
}
