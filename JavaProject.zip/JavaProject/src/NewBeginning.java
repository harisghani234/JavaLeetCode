public class NewBeginning {
    public static void main(String[] args) {

    }

}
