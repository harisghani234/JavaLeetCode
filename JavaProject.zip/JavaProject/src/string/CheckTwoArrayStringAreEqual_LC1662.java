package string;

public class CheckTwoArrayStringAreEqual_LC1662 {
    //    Input: word1 = ["ab", "c"], word2 = ["a", "bc"]
//    Output: true
//    Input: word1 = ["a", "cb"], word2 = ["ab", "c"]
//    Output: false
//    Input: word1  = ["abc", "d", "defg"], word2 = ["abcddefg"]
//    Output: true
    public static void main(String[] args) {
        String[] word1 = {"a", "cb"};
        String[] word2 = {"ab", "c"};
        System.out.println(arrayStringsAreEqual(word1, word2));

    }
    public static boolean arrayStringsAreEqual(String[] word1, String[] word2) {
        StringBuilder final_w1 = new StringBuilder("");
        StringBuilder final_w2 = new StringBuilder("");
        for(int i=0;i<word1.length;i++){
            final_w1 =final_w1.append(word1[i]);
        }
        for(int i=0;i<word2.length;i++){
            final_w2 =final_w2.append(word2[i]);
        }
        System.out.println(final_w2);
        System.out.println(final_w1);
        if(!word1.equals(word2))
            return false;
        return true;
    }
}
