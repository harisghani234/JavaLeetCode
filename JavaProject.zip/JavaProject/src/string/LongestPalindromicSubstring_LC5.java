package string;

public class LongestPalindromicSubstring_LC5 {
    public static void main(String[] args) {
//        String s = "racecad";
        String s = "harisabbaghaaabbaaanif";
        System.out.println(s.length());
        findlongestpalindrome(s);
    }

    /*
      this function will find the longest palindrome and print
   */
    public static void findlongestpalindrome(String s) {
        String output = "";
        int i = 0;

        //odd
        while (i < s.length()) {
            int l = i - 1;
            int r = i + 1;
            if (l >= 0 && r < s.length()) {
                while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) {
                    System.out.println(s.substring(l, r + 1));
                    if (output.length() <= s.substring(l, r + 1).length()) {
                        System.out.println(s.substring(l, r + 1));
                        output = s.substring(l, r + 1);
                    }
                    l--;
                    r++;
                }
            }
            i++;


        }
        //even
        i = 0;
        while (i < s.length()) {
            if(i+1 < s.length() && s.charAt(i)==s.charAt(i+1)){
                int l = i-1;
                int r = i + 2;
                if (l >= 0 && r < s.length()) {
                    while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) {
                        if (output.length() <= s.substring(l, r + 1).length()) {
                            output = s.substring(l, r + 1);
                        }
                        l--;
                        r++;
                    }
                }
                i++;
            }
        }
        System.out.println("The biggest palindromic substring " + output);
    }
}
