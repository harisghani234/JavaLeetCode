package oops;

public class CustExep {
    public static void main(String[] args) {
        int a =-44;
        if(a<0){
            throw new CustException("User has entered invalid number");
        }else{
            System.out.println("user entered correct data");
        }
    }
}
class CustException extends RuntimeException {
    public CustException(String message) {
        super(message);
    }
}
