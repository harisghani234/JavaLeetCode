package oops;

public class SingletonWithParameter {
    private static SingletonWithParameter t = null;
    int id ;
    private SingletonWithParameter(int id){
        this.id = id;
    }

    public static SingletonWithParameter factoryMethod(int id){
        if(t==null){
            t = new SingletonWithParameter(id);
        }
        return t;
    }

    public static void main(String[] args) {
        SingletonWithParameter t1 = SingletonWithParameter.factoryMethod(34);
        System.out.println(t1);
        SingletonWithParameter t2 = SingletonWithParameter.factoryMethod(54);
        System.out.println(t2);
        SingletonWithParameter t3 = SingletonWithParameter.factoryMethod(13);
        System.out.println(t3.id);

    }
}
