package oops;

public class Singleton {
    // only one object is created in the entire application
    // constructor is made private
    // only one method which returns the class object address
    // if we create multiple object, then all would point to the address of first object

    static Singleton test = new Singleton();

    private Singleton(){

    }
    public static Singleton getTestFunctionOfSingleton(){
        return test;
    }

    public static void main(String[] args) {
        Singleton t1 = Singleton.getTestFunctionOfSingleton();
        System.out.println(t1);
        Singleton t2 = Singleton.getTestFunctionOfSingleton();
        System.out.println(t2);
    }
}
