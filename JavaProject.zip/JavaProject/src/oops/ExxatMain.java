package oops;

public class ExxatMain extends AB implements Exxat_Interface {
    public static void main(String[] args) {
        ExxatMain obj = new ExxatMain();
        obj.multiply();
        obj.sum1(10,20);
        AB obj_superClass = new ExxatMain();
        obj_superClass.sum(20,30);
        obj_superClass.multiply();
        Exxat_Interface obj_Interface = new ExxatMain();
        obj_Interface.sum1(4,7);
    }

    public void multiply(){
        System.out.println("Giving implementation to abstract method of parent class");
    }

    public void sum1(int a, int b){
        System.out.println("Method of Interface" + (a+b));
    }


}

abstract class AB{
    public int sum(int a , int b){
        return (a+b);
    }
    public abstract void multiply();


}

