package oops;

import java.util.Stack;

public class Exc extends RuntimeException{

    public static void main(String[] args) {
        String s = "{}()[()]()(";
        System.out.println(checkValidParanthesis(s));
    }

    public static boolean checkValidParanthesis(String s){
        Stack<Character> stack = new Stack<>();
        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            if(c=='{' || c == '(' || c == '['){
                stack.push(c);
            }
            else{
                if(stack.size()!=0 && c == ')'){
                    if(stack.peek() !='('){
                        return false;
                    }else {
                        stack.pop();
                    }
                }
                else if(stack.size()!=0 && c == '}'){
                    if(stack.peek() !='{'){
                        return false;
                    }else {
                        stack.pop();
                    }
                }
                else if(stack.size()!=0 && c == ']'){
                    if(stack.peek() !='['){
                        return false;
                    }else {
                        stack.pop();
                    }
                }
                else{
                    return false;
                }
            }
        }
        return true;
    }

}
