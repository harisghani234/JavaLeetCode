package oops;

public interface Exxat_Interface {
    void sum1(int a , int b);
}
