package oops;

public class CustomException extends RuntimeException {
    public CustomException (String exceptionMessage){
        super(exceptionMessage);
    }
}
