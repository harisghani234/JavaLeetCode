package org.practice;

public class Test1 {

    public static void main(String[] args) {
       String s = "aeaabbccccddd";
//        String s = "a";
       StringBuffer output = new StringBuffer("");
       int count = 1;
       char c = s.charAt(0);
       for(int i=1; i<s.length(); i++){
           if(s.charAt(i)==c){
               count++;
           }else{
               output.append(c).append(count);
               c=s.charAt(i);
               count=1;
           }
           if(i == s.length()-1){
               output.append(c).append(count);
           }
       }

        System.out.println(output);
    }
}
