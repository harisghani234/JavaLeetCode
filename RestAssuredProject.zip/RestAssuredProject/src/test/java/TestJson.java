import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class TestJson {
    public static void main(String[] args) {
        method1();
        method2();
    }
    public static void method1(){
        System.out.println("print1");
        String filePath = "payload1.json";
        String copyFilePath = "payload_copy.json";
        ObjectMapper objectMapper = new ObjectMapper();
//
//        MyDataClass data = objectMapper.readValue(new File(filePath), MyDataclass);

    }

    public static void method2(){
        System.out.println("print2");
    }
}
