import io.restassured.path.json.JsonPath;

import java.util.List;

public class SafeSendTest {
    public static void main(String[] args) {
        String response = "[\n" +
                "  {\n" +
                "    \"name\": \"haris\",\n" +
                "    \"email\": \"26\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"name\": \"aquil\",\n" +
                "    \"email\": \"5\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"name\": \"hammad\",\n" +
                "    \"email\": \"15\"\n" +
                "  }\n" +
                "]";


//        System.out.println(response);
        JsonPath js = new JsonPath(response);
        List<String> li = js.getList("");
        System.out.println(li.size());
        System.out.println(js.getString("name"));
        for(int i =0; i<li.size(); i++){
            String namePath = "name["+i+"]";

            if(js.getString(namePath).equals("hammad")) {
                String fetchEmail = "email[" + i + "]";
                System.out.println(js.getString(fetchEmail));
            }

        }
        System.out.println("*************");
        for(int i=0; i<li.size(); i++){
            String namePath = "["+i+"].name";
            String emailPath = "["+i+"].email";
            if(js.getString(namePath).equals("hammad")){
                System.out.println(js.getString(emailPath));
            }
        }

    }



}
