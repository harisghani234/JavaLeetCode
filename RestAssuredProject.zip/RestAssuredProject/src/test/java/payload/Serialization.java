package payload;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.testng.annotations.Test;

public class Serialization {
    @Test
    public void serializationTest(){
        POJO_TestObject test1 = new POJO_TestObject();
        test1.setFirstName("Haris");
        test1.setLastName("Ghani");
        ObjectMapper mapper = new ObjectMapper();
    }
}
