package payload;

public class POJO_TestObject {
    private String firstName;
    private String lastName;
    private String address;

    private int age;
    private int salary;

    public String getFirstName(){
        return firstName;
    }
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
}
