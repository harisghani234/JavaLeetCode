package rahulShetty.Basic;

import io.restassured.RestAssured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class AddPlace_updated2_responseAssert {
    public static void main(String[] args) {


        String baseURI = "https://rahulshettyacademy.com";
        String addPlaceEndpoint = "maps/api/place/add/json";
        String queryParamKey_Value = "qaclick123";
        String contentType_key = "Content-Type";
        String application_json = "application/json";
        String payload_addplace = "{\n" +
                "  \"location\": {\n" +
                "    \"lat\": -38.383494,\n" +
                "    \"lng\": 33.427362\n" +
                "  },\n" +
                "  \"accuracy\": 50,\n" +
                "  \"name\": \"Haris Ghani House\",\n" +
                "  \"phone_number\": \"(+91) 983 893 3937\",\n" +
                "  \"address\": \"29, side layout, cohen 09\",\n" +
                "  \"types\": [\n" +
                "    \"shoe park\",\n" +
                "    \"shop\"\n" +
                "  ],\n" +
                "  \"website\": \"http://google.com\",\n" +
                "  \"language\": \"French-IN\"\n" +
                "}";


        RestAssured.baseURI = baseURI;
                given().relaxedHTTPSValidation().log().all().queryParam("key", queryParamKey_Value).
                header(contentType_key,application_json).
                body(payload_addplace).
                when().post(addPlaceEndpoint)
                .then().log().all().assertThat().statusCode(200).body("scope", equalTo("APP"), "status", equalTo("OK"));
    }
}
