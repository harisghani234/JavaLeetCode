package rahulShetty.Basic;

import io.restassured.RestAssured;
import payload.AddPlacePayload;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

// here we separate the payload to diff package
public class AddPlace_updated3 {
    public static void main(String[] args) {


        String baseURI = "https://rahulshettyacademy.com";
        String addPlaceEndpoint = "maps/api/place/add/json";
        String queryParamKey_Value = "qaclick123";
        String contentType_key = "Content-Type";
        String application_json = "application/json";
        String payload_addplace = AddPlacePayload.addPLace();

        RestAssured.baseURI = baseURI;
                given().relaxedHTTPSValidation().log().all().queryParam("key", queryParamKey_Value).
                header(contentType_key,application_json).
                body(payload_addplace).
                when().post(addPlaceEndpoint)
                .then().log().all().assertThat().statusCode(200).body("scope", equalTo("APP"), "status", equalTo("OK"));
    }
}
