import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;

public class FreeAPI {

    public static void main(String[] args) {


        RestAssured.baseURI = "https://fake-json-api.mock.beeceptor.com";

//        String response = given().log().all().header("Content-Type", "application/json")
//                .when().get("companies")
//                .then().log().all().statusCode(200)
//                .extract().response().body().asString();

        String response = "[\n" +
                "    {\n" +
                "        \"id\": 1,\n" +
                "        \"name\": \"Krajcik and Sons\",\n" +
                "        \"address\": \"47031 Dach Cape\",\n" +
                "        \"zip\": \"36595\",\n" +
                "        \"country\": \"Cambodia\",\n" +
                "        \"employeeCount\": 0,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 245905,\n" +
                "        \"domain\": \"descriptive-permit.biz\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Julian Berge\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 2,\n" +
                "        \"name\": \"Hauck - McGlynn\",\n" +
                "        \"address\": \"847 Treutel Causeway\",\n" +
                "        \"zip\": \"14296\",\n" +
                "        \"country\": \"Ukraine\",\n" +
                "        \"employeeCount\": 5,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 305979,\n" +
                "        \"domain\": \"icky-shopper.info\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Leanne Schultz\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 3,\n" +
                "        \"name\": \"Ernser - Wunsch\",\n" +
                "        \"address\": \"8995 Laura Key\",\n" +
                "        \"zip\": \"88164\",\n" +
                "        \"country\": \"Democratic Republic of the Congo\",\n" +
                "        \"employeeCount\": 1,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 353330,\n" +
                "        \"domain\": \"pricey-lacquerware.com\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Nora Morar\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 4,\n" +
                "        \"name\": \"Stoltenberg Group\",\n" +
                "        \"address\": \"811 Pink Village\",\n" +
                "        \"zip\": \"68478\",\n" +
                "        \"country\": \"Kenya\",\n" +
                "        \"employeeCount\": 6,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 438383,\n" +
                "        \"domain\": \"sandy-chive.org\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Odell Schiller\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 4,\n" +
                "        \"name\": \"Mills Inc\",\n" +
                "        \"address\": \"66570 Old State Road\",\n" +
                "        \"zip\": \"12467\",\n" +
                "        \"country\": \"Hungary\",\n" +
                "        \"employeeCount\": 10,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 442339,\n" +
                "        \"domain\": \"unkempt-originality.org\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Frankie Borer\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 5,\n" +
                "        \"name\": \"Langosh, Wolff and McClure\",\n" +
                "        \"address\": \"51212 Roman Way\",\n" +
                "        \"zip\": \"41889\",\n" +
                "        \"country\": \"Cameroon\",\n" +
                "        \"employeeCount\": 8,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 9704,\n" +
                "        \"domain\": \"personal-vicinity.name\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Jany Johns\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 6,\n" +
                "        \"name\": \"Gerhold - Gusikowski\",\n" +
                "        \"address\": \"870 Godfrey Shoal\",\n" +
                "        \"zip\": \"54841\",\n" +
                "        \"country\": \"Uzbekistan\",\n" +
                "        \"employeeCount\": 5,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 292006,\n" +
                "        \"domain\": \"altruistic-apple.org\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Rosalee Lueilwitz\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 7,\n" +
                "        \"name\": \"Kerluke - Fay\",\n" +
                "        \"address\": \"736 E Broadway Street\",\n" +
                "        \"zip\": \"71877\",\n" +
                "        \"country\": \"Malawi\",\n" +
                "        \"employeeCount\": 3,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 973750,\n" +
                "        \"domain\": \"silent-departure.name\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Meredith Langworth\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 8,\n" +
                "        \"name\": \"Conroy - Schaefer\",\n" +
                "        \"address\": \"8886 S 5th Street\",\n" +
                "        \"zip\": \"72851\",\n" +
                "        \"country\": \"Tanzania\",\n" +
                "        \"employeeCount\": 4,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 801920,\n" +
                "        \"domain\": \"strange-senate.com\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Quentin Harber\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 9,\n" +
                "        \"name\": \"Williamson, Jenkins and Greenholt\",\n" +
                "        \"address\": \"18532 Trisha Courts\",\n" +
                "        \"zip\": \"04958\",\n" +
                "        \"country\": \"Philippines\",\n" +
                "        \"employeeCount\": 7,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 898936,\n" +
                "        \"domain\": \"luminous-taro.info\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Cecil Towne\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"id\": 10,\n" +
                "        \"name\": \"Gislason and Sons\",\n" +
                "        \"address\": \"75943 Moss Lane\",\n" +
                "        \"zip\": \"28770-4427\",\n" +
                "        \"country\": \"Angola\",\n" +
                "        \"employeeCount\": 6,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 543145,\n" +
                "        \"domain\": \"detailed-woodwind.name\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Clementina Schulist\"\n" +
                "    }\n" +
                "]";

        String response2 = " {\n" +
                "        \"id\": 1,\n" +
                "        \"name\": \"Krajcik and Sons\",\n" +
                "        \"address\": \"47031 Dach Cape\",\n" +
                "        \"zip\": \"36595\",\n" +
                "        \"country\": \"Cambodia\",\n" +
                "        \"employeeCount\": 0,\n" +
                "        \"industry\": \"Technology\",\n" +
                "        \"marketCap\": 245905,\n" +
                "        \"domain\": \"descriptive-permit.biz\",\n" +
                "        \"logo\": \"https://example.com/logo1.png\",\n" +
                "        \"ceoName\": \"Julian Berge\",\n" +
                "        \"test\": [\n" +
                "          {\n" +
                "          \"name\": \"haris\"\n" +
                "          },\n" +
                "          {\n" +
                "          \"name\": \"aquil\"\n" +
                "          },\n" +
                "          {\n" +
                "          \"name\": \"hammad\"\n" +
                "          }\n" +
                "        ]\n" +
                "    }";



//        System.out.println(response);
        JsonPath path = new JsonPath(response);
        System.out.println(path.getString("logo"));



        System.out.println(path.getString("?id>4"));

//        System.out.println(path.getList("test[*].name"));

//        System.out.println(response.[1].id);
    }
}
