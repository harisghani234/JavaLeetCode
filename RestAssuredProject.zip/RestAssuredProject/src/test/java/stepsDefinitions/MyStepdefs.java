package stepsDefinitions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class MyStepdefs {
    @Given("I print first line")
    public void i_print_first_line() {
        System.out.println("hello, its my first line");
        throw new io.cucumber.java.PendingException();
    }
    @Then("I am happy")
    public void i_am_happy() {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("now, its end here, i am happy");
    }
}
