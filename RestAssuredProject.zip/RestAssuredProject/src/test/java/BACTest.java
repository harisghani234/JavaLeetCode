import io.restassured.path.json.JsonPath;
import org.openqa.selenium.json.Json;

import java.util.List;

public class BACTest {
    public static void main(String[] args) {
        String response = "{\n" +
                "  \"company\": {\n" +
                "    \"name\": \"Tech Solutions Inc.\",\n" +
                "    \"location\": {\n" +
                "      \"address\": {\n" +
                "        \"street\": \"123 Main St\",\n" +
                "        \"city\": \"San Francisco\",\n" +
                "        \"state\": \"CA\",\n" +
                "        \"zipcode\": \"94105\"\n" +
                "      },\n" +
                "      \"office_locations\": [\n" +
                "        {\n" +
                "          \"city\": \"New York\",\n" +
                "          \"country\": \"USA\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"city\": \"London\",\n" +
                "          \"country\": \"UK\"\n" +
                "        }\n" +
                "      ]\n" +
                "    },\n" +
                "    \"employees\": [\n" +
                "      {\n" +
                "        \"id\": 101,\n" +
                "        \"name\": \"Alice Johnson\",\n" +
                "        \"role\": \"Software Engineer\",\n" +
                "        \"skills\": [\n" +
                "          \"JavaScript\",\n" +
                "          \"Python\",\n" +
                "          \"React\"\n" +
                "        ],\n" +
                "        \"projects\": [\n" +
                "          {\n" +
                "            \"project_id\": \"A1\",\n" +
                "            \"name\": \"Web Application\",\n" +
                "            \"status\": \"Completed\",\n" +
                "            \"team\": [\n" +
                "              \"Alice Johnson\",\n" +
                "              \"Bob Smith\"\n" +
                "            ]\n" +
                "          },\n" +
                "          {\n" +
                "            \"project_id\": \"A2\",\n" +
                "            \"name\": \"Mobile App\",\n" +
                "            \"status\": \"In Progress\",\n" +
                "            \"team\": [\n" +
                "              \"Alice Johnson\"\n" +
                "            ]\n" +
                "          }\n" +
                "        ]\n" +
                "      },\n" +
                "      {\n" +
                "        \"id\": 102,\n" +
                "        \"name\": \"Bob Smith\",\n" +
                "        \"role\": \"Data Scientist\",\n" +
                "        \"skills\": [\n" +
                "          \"Python\",\n" +
                "          \"Machine Learning\",\n" +
                "          \"Data Analysis\"\n" +
                "        ],\n" +
                "        \"projects\": [\n" +
                "          {\n" +
                "            \"project_id\": \"A1\",\n" +
                "            \"name\": \"Web Application\",\n" +
                "            \"status\": \"Completed\",\n" +
                "            \"team\": [\n" +
                "              \"Alice Johnson\",\n" +
                "              \"Bob Smith\"\n" +
                "            ]\n" +
                "          },\n" +
                "          {\n" +
                "            \"project_id\": \"B1\",\n" +
                "            \"name\": \"Data Pipeline\",\n" +
                "            \"status\": \"In Progress\",\n" +
                "            \"team\": [\n" +
                "              \"Bob Smith\",\n" +
                "              \"Charlie Lee\"\n" +
                "            ]\n" +
                "          }\n" +
                "        ]\n" +
                "      }\n" +
                "    ],\n" +
                "    \"products\": {\n" +
                "      \"web_app\": {\n" +
                "        \"version\": \"1.2.3\",\n" +
                "        \"release_date\": \"2022-10-05\",\n" +
                "        \"features\": [\n" +
                "          \"User Authentication\",\n" +
                "          \"Data Visualization\",\n" +
                "          \"Export Data\"\n" +
                "        ]\n" +
                "      },\n" +
                "      \"mobile_app\": {\n" +
                "        \"version\": \"0.9.1\",\n" +
                "        \"release_date\": \"2023-01-12\",\n" +
                "        \"features\": [\n" +
                "          \"Push Notifications\",\n" +
                "          \"In-app Purchases\"\n" +
                "        ]\n" +
                "      }\n" +
                "    }\n" +
                "  }\n" +
                "}";

        JsonPath js = new JsonPath(response);
        List<String> list = js.getList("company.employees");
//        System.out.println(list);
        for(int i=0; i<list.size(); i++){
            List<String> list2 = js.getList("company.employees["+i+"].skills");
//            System.out.println(list2);
            for(int j=0; j<list2.size();j++){
                String skills = js.getString("company.employees["+i+"].skills["+j+"]");
                if(skills.equals("Python")){
                    String empName = js.getString("company.employees["+i+"].name");
                    System.out.println(empName);

                }
            }
        }



    }
}
