import io.cucumber.java.sl.In;
import io.restassured.path.json.JsonPath;

import java.util.List;

public class SahilParsing {
    public static void main(String[] args) {

        String response = "{\n" +
                "  \"organization\": {\n" +
                "    \"id\": 1,\n" +
                "    \"name\": \"Alice\",\n" +
                "    \"title\": \"CEO\",\n" +
                "    \"subordinates\": [\n" +
                "      {\n" +
                "        \"id\": 2,\n" +
                "        \"name\": \"Bob\",\n" +
                "        \"title\": \"CTO\",\n" +
                "        \"subordinates\": [\n" +
                "          {\n" +
                "            \"id\": 4,\n" +
                "            \"name\": \"David\",\n" +
                "            \"title\": \"Senior Engineer\",\n" +
                "            \"subordinates\": [\n" +
                "              {\n" +
                "                \"id\": 8,\n" +
                "                \"name\": \"Manish\",\n" +
                "                \"title\": \"Senior Engineer\",\n" +
                "                \"subordinates\": []\n" +
                "              }\n" +
                "            ]\n" +
                "          },\n" +
                "          {\n" +
                "            \"id\": 5,\n" +
                "            \"name\": \"Eva\",\n" +
                "            \"title\": \"Software Engineer\",\n" +
                "            \"subordinates\": []\n" +
                "          }\n" +
                "        ]\n" +
                "      },\n" +
                "      {\n" +
                "        \"id\": 3,\n" +
                "        \"name\": \"Charlie\",\n" +
                "        \"title\": \"CFO\",\n" +
                "        \"subordinates\": [\n" +
                "          {\n" +
                "            \"id\": 6,\n" +
                "            \"name\": \"Frank\",\n" +
                "            \"title\": \"Financial Analyst\",\n" +
                "            \"subordinates\": []\n" +
                "          }\n" +
                "        ]\n" +
                "      }\n" +
                "    ]\n" +
                "  }\n" +
                "}";
        boolean isIdPresent = true;
        System.out.println(response);
        JsonPath js = new JsonPath(response);
        int li_id;
        try {
            li_id = js.getInt("organization.id");
            // if id is present print direct subordinates

            // if no

        }catch (Exception e){
            isIdPresent = false;
            li_id = 0;
        }
        if(isIdPresent){

        }
    }
}
