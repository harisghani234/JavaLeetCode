
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.security.Key;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class MyStepdefs {
    public static void main(String[] args) throws Exception{
        System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Python310\\Scripts\\chromedriver.exe");
        ChromeOptions ch = new ChromeOptions();
        WebDriver driver = new ChromeDriver(ch);
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
//        Thread.sleep(3000);
        System.out.println(  driver.getTitle());
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        WebElement textInput_Textbox = driver.findElement(By.id("my-text-id"));
        String valueInputTextbox = "haris ghani";
        textInput_Textbox.sendKeys(valueInputTextbox);

        WebElement password_Textbox = driver.findElement(By.name("my-password"));
        String passwordTextbox = "siemens@123";
        password_Textbox.sendKeys(passwordTextbox);

        WebElement textArea_Textbox = driver.findElement(By.name("my-textarea"));
        String textAreaTextbox = "siemensgamesa12345";
        textArea_Textbox.sendKeys(textAreaTextbox);

        WebElement disabled_Textbox = driver.findElement(By.name("my-disabled"));
        boolean disabledStatus = disabled_Textbox.isEnabled();
        System.out.println("status of disabled textbox - "+disabledStatus);
        String placeholder_disabledTextbox = disabled_Textbox.getAttribute("placeholder");
        System.out.println(placeholder_disabledTextbox);

        WebElement indexLink_Xpath = driver.findElement(By.xpath("//a[contains(text(),'Return to index')]"));
        indexLink_Xpath.click();
        System.out.println("The page title of index link page is - "+ driver.getTitle());
        driver.navigate().back();
        System.out.println("The page title of main page is - "+ driver.getTitle());

        // single dropdown - print all elements and select Three
        WebElement ddSelect_className = driver.findElement(By.className("form-select"));
        Select sel = new Select(ddSelect_className);
        List<WebElement> list = sel.getOptions();
        System.out.println("Printing list of all webelements");
        for(int i=0;i<list.size();i++){
            System.out.println(list.get(i).getText());
        }
        sel.selectByVisibleText("Three");

        // auto suggestion input box
        WebElement datalistAutoSuggestion_Xpath = driver.findElement(By.xpath("//input[@list='my-options']"));
//        datalistAutoSuggestion_Xpath.click();
//        datalistAutoSuggestion_Xpath.sendKeys("L");

        // here 2 options would come and now i have to select the first option
        Actions action =  new Actions(driver);
        action.moveToElement(datalistAutoSuggestion_Xpath).click().sendKeys("L").sendKeys(Keys.DOWN).sendKeys(Keys.ARROW_DOWN).perform();
//        action.moveToElement(datalistAutoSuggestion_Xpath).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).click().perform();
//        action.dragAndDrop().perform();







//        Set<String> allWindowHandles = driver.getWindowHandles();
//        String currentWindowHandle = driver.getWindowHandle();
//
//        for(String windowHandles: allWindowHandles ){
//            // ignore the current window
//            if(!windowHandles.equals(currentWindowHandle)){
//                driver.switchTo().window(windowHandles);
//                System.out.println("The page title of new window handle is - "+ driver.getTitle());
//                driver.close();
//            }
//        }
//        // switching back to main window
//        driver.switchTo().window(currentWindowHandle);
//        System.out.println("Current window Handle is - "+ driver.getTitle());




        Thread.sleep(5000);

        driver.quit();
    }

}
