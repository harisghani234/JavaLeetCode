import io.restassured.path.json.JsonPath;


import java.util.List;

public class Parse2 {
    public static void main(String[] args) {
        String response = "{\n" +
                "  \"dashboard\": {\n" +
                "    \"purchaseAmount\": 1060,\n" +
                "    \"website\": \"code2test.com\"\n" +
                "  },\n" +
                "  \"courses\": [\n" +
                "    {\n" +
                "      \"title\": \"Selenium\",\n" +
                "      \"price\": 50,\n" +
                "      \"copies\": 6\n" +
                "    },\n" +
                "    {\n" +
                "      \"title\": \"Appium\",\n" +
                "      \"price\": 40,\n" +
                "      \"copies\": 4\n" +
                "    },\n" +
                "    {\n" +
                "      \"title\": \"Rest Assured\",\n" +
                "      \"price\": 45,\n" +
                "      \"copies\": 10\n" +
                "    },\n" +
                "    {\n" +
                "      \"title\": \"SoapUI\",\n" +
                "      \"price\": 30,\n" +
                "      \"copies\": 5\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        JsonPath js = new JsonPath(response);

//"a) Get the purchase amount of the course?
        System.out.println(js.getInt("dashboard.purchaseAmount"));
//
//b) Title of first course (which is selenium) ?
        System.out.println(js.getString("courses[0].title"));
//
//c) Total copies sold by SoapUI?
        String param = "SoapUI";
        List<String> allCoursesAsList = js.getList("courses");
        for(int i = 0; i<allCoursesAsList.size();i++){
            if(js.getString("courses["+i+"].title").equals(param)) {
                System.out.println("found");
                System.out.println(js.getString("courses[" + i + "].copies"));
            }
        }

//
//d) Total number of courses?
       int size = js.getList("courses").size();
       System.out.println(size);
       // OR
       int size2 = js.getInt("courses.size()");
        System.out.println(size2);
//
//e) Print all the title of the courses"
        List<String> li = js.getList("");
        for(int i=0;i<li.size();i++){
            System.out.println(js.getString("courses["+ i+ "].title"));
        }

// total purchase price
        int sum = 0;
        List<String> li2 = js.getList("courses");
        for(int i =0; i<li2.size(); i++){
            int price = js.getInt("courses["+i+"].price");
            sum = sum+price;
        }
        System.out.println("total sum is = "+sum);
    }
}
