import io.restassured.RestAssured;
import org.testng.annotations.Test;

public class APIBasicTest {
    public static void main(String[] args) {

//        RestAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";



    }

    @Test
    public void test1(){
        System.out.println("Hello");
    }
    @Test
    public void test2(){
        System.out.println("Hi");
    }
}
