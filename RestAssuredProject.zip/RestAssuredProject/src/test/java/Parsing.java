import io.cucumber.java.sl.In;
import io.restassured.path.json.JsonPath;
import org.openqa.selenium.json.Json;

import java.util.Iterator;
import java.util.List;


public class Parsing {
    public static void main(String[] args) {
        String namePath  = "name";
        String addressPath = "address";
        String typePath_dynamic = "address.[%i].type";


        String response = "{\n" +
                "    \"name\": \"sarath\",\n" +
                "    \"id\": \"501\",\n" +
                "    \"address\": [\n" +
                "        {\n" +
                "            \"type\": \"home\",\n" +
                "            \"street\": \"mg road\",\n" +
                "            \"city\": \"bangalore\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"type\": \"office\",\n" +
                "            \"street\": \"miyapur\",\n" +
                "            \"city\": \"hyderabad\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";

        JsonPath js = new JsonPath(response);
        List<String> listOfAddressType = js.getList("address.type");
        for(String type: listOfAddressType){
            if(type.equals("office")){
                System.out.println(js.getString("address.street"));
                System.out.println(js.getString("address.city"));
            }
        }

    }
}
