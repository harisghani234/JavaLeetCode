package oops;

import java.util.Scanner;

public class CustomExceptionMainClass {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter amount to withdraw");
        int amount = sc.nextInt();
        if(amount<0){
            throw new CustomException("You entered an invalid amount" );
        }
        System.out.println("Success");
    }
}
