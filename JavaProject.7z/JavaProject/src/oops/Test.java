package oops;

public class Test {
    public static void main(String[] args) {
        String s = "aaabbcddee";
        String output = ""+s.charAt(0);
        int l =1;
        char c = s.charAt(0);
        int count = 1;

        while (l<s.length()){
            if(s.charAt(l) == c){
                count++;
                l++;
            }else{
                output = output+count;
                count=1;
                c = s.charAt(l);
                l++;
                output = output+c;
            }
            if (s.length()== l) {
                output = output+count;

            }
        }
        System.out.println(output);


    }
}
