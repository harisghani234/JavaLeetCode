package java8;

public class LambdaExpression {
    public static void main(String[] args) {


    }

}
