package basics;

import java.lang.reflect.Array;
import java.util.Arrays;

public class StringBasics {
    public static void main(String[] args) {
        reverseString("haris ghani");
//        reverseString("my name is haris ghani");
        checkPalindrome("");
        checkComplexPalindrome("A man, a plan, a canal: Panama");
    }
    public static void reverseString(String s){
//       String output = "";
//       for(int i=s.length()-1;i>=0;i--){
//           output=output+s.charAt(i);
//       }
//        System.out.println(output);

        // approach 2 with half loop
        char [] arr = s.toCharArray();
        for(int i =0;i<arr.length/2;i++){
            char temp = arr[i];
            arr[i]=arr[arr.length-1-i];
            arr[arr.length-1-i]=temp;
        }
        System.out.println(arr);
    }

    public static void checkPalindrome(String s){
        int l=0;
        int r=s.length()-1;
        boolean result = true;
        while(l<r){
            if(s.charAt(l)==s.charAt(r)){
                l++;r--;
            }else{
                result = false;
                break;
            }
        }
        System.out.println(result);
    }

    public static void checkComplexPalindrome(String s){
        s=s.toLowerCase();
        int l=0;int r=s.length()-1;
        boolean result = true;
        while (l<r){
            if(checkForCharacterOrDigit(s.charAt(l)) || checkForCharacterOrDigit(s.charAt(r))){
                if(s.charAt(l)!=s.charAt(r)){
                    result = false;
                    break;
                }
            }

        }
    }
    public static boolean checkForCharacterOrDigit(char c){
        if(!(c-'a'>=0 && c-'a'<26 ||c>='0' &&c<=9))
            return false;
        return true;
    }
}
