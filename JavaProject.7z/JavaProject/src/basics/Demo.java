package basics;

import java.util.*;

public class Demo {
    public static void main(String[] args) {
        String s = "haris ghani";
        firstNonRepeatingCharacter(s);
        firstDuplicateCharacter(s);
//        characterWithMaxOccurance(s);

        String s2 = "aaabbccccd";
        String s3 = "aaabbccccddd";
        stringCompression(s2);
        stringCompression(s3);

    }
    static void firstNonRepeatingCharacter(String s){
        HashMap<Character, Integer> hmap = new HashMap<>();
        for(int i =0; i<s.length(); i++){
            if(hmap.containsKey(s.charAt(i)))
                hmap.put(s.charAt(i), hmap.get(s.charAt(i))+1);
            else
                hmap.put(s.charAt(i),1);
        }
//        for(Map.Entry<Character, Integer> var : hmap.entrySet()){
//            System.out.println("key - "+var.getKey() + "  value - "+var.getValue());
//        }
        for(int i =0; i<s.length(); i++){
            if(hmap.get(s.charAt(i))==1) {
                System.out.println("first non repeating char is - " + s.charAt(i));
                break;
            }
            else
                System.out.println("no non repeating character found");
        }

    }

    static void firstDuplicateCharacter(String s){
        HashMap<Character, Integer> hmap = new HashMap<>();
        for(int i =0; i<s.length(); i++){
            if(hmap.containsKey(s.charAt(i)))
                hmap.put(s.charAt(i), hmap.get(s.charAt(i))+1);
            else
                hmap.put(s.charAt(i),1);
        }
        for(int i =0; i<s.length(); i++){
            if(hmap.get(s.charAt(i))>1) {
                System.out.println("first duplicate char is - " + s.charAt(i));
                break;
            }
            else
                System.out.println("no duplicate character found");
        }

    }

    static void characterWithMaxOccurance(String s){
        HashMap<Character, Integer> hmap = new HashMap<>();
        ArrayList<Character> al = new ArrayList<>();
        for(int i =0; i<s.length(); i++){
            if(hmap.containsKey(s.charAt(i)))
                hmap.put(s.charAt(i), hmap.get(s.charAt(i))+1);
            else
                hmap.put(s.charAt(i),1);
        }
        int maxOccuranceCount = 1;
        for(Map.Entry<Character, Integer> var :hmap.entrySet()){
            if(var.getValue()>1){
                System.out.println(var.getKey());
                maxOccuranceCount = var.getValue();
            }
        }
        System.out.println(maxOccuranceCount);
        for(Map.Entry<Character, Integer> var :hmap.entrySet()){
            if(var.getValue()==maxOccuranceCount)
                al.add(var.getKey());
        }
        System.out.println(al);

        System.out.println("The Max occurance is found for character - "+ al.toString());


    }

    static void stringCompression(String s){
        int lp = 0;
        int rp = 1;
        int count =1;
        String output = "";
        while(rp<s.length()){
            if(s.charAt(lp) == s.charAt(rp)){
                count++;
            }else{
                output = output+s.charAt(lp)+count;
                lp = rp;
                count = 1;
            }
            if(rp==s.length()-1){
                output = output+s.charAt(lp)+count;
            }
            rp++;
        }
        System.out.println(output);
    }

}
