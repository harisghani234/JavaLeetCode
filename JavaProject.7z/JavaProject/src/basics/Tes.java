package basics;

import java.util.*;

public class Tes {

    public static void main(String[] args) {
//        String[] words = {"Leet", "Code"};
//        char c = 'e';
//        System.out.println(findWordsContaining(words, c));
        findAllSubstring("sad");


    }

    public static List<Integer> findWordsContaining(String[] words, char x) {
        List<Integer> al = new ArrayList<>();

        for (int i = 0; i < words.length; i++) {
            for (int j = 0; j < words[i].length(); j++) {
                if (words[i].charAt(j) == x) {
                    al.add(i);
                    break;
                }
            }
        }
        return al;
    }

    public static void findAllSubstring(String input) {
        ArrayList<String> al = new ArrayList<>();

        for (int i = 0; i < input.length(); i++) {
            for(int j=i+1; j<=input.length(); j++){
                al.add(input.substring(i,j));
            }
        }
        System.out.println(al);
    }
}
