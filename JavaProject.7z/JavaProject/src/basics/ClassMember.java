package basics;

public class ClassMember {
    public static void main(String[] args) {
//        static int a = 100; //CTE as static variable has to be always defined outside the method,
        System.out.println(Sample1.a);
        Sample1.method();
    }
}

class Sample1{
    static String a ="haris";
    static void method(){
        System.out.println("Hello");
    }
}
