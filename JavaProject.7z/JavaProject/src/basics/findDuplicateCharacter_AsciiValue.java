package basics;

public class findDuplicateCharacter_AsciiValue {
    public static void main(String[] args) {
        String input = "aaabbcdddeef";
        int[] arr = new int[26];
        for (int i = 0; i < input.length(); i++) {
            int index = input.charAt(i) - 'a';
            arr[index] = arr[index] + 1;
        }
        for(int i=0; i<arr.length; i++){
            int asciiValue = 'a'+i;
            // converting ascii to character
            char c = (char) asciiValue;
            if(arr[i]>1){
                System.out.println("Duplicate Element with occurance "+ c + " - "+ arr[i]);
                continue;
            }else if(arr[i] == 1)
                System.out.println("unique element - "+ c);
        }
    }
}
