package string;

import java.util.ArrayList;
import java.util.List;

public class Palindrome_LC5 {
    public static void main(String[] args) {
        String s = "babbadcdabadcd";
        printlongestPalindrome(s);

    }

    public static void printlongestPalindrome(String s) {
        // edge case
        if (s.length() == 0 || s.length() == 1) {
            System.out.println("the input itself is a palindrome" + s);
            System.exit(0);
        }
        ArrayList<String> al = new ArrayList<>();
        String longestPalindromicString = "";
        for (int i = 0; i < s.length() - 1; i++) {
            // odd check
            al.add(checkPalindrome(i, i, s));
            // even check
            al.add(checkPalindrome(i, i + 1, s));
        }
        System.out.println(al);
        int max = 0;
        String output = "";
        for (int i = 0; i < al.size(); i++) {
            if (max <= al.get(i).length()) {
                max = al.get(i).length();
                output = al.get(i);
            }
        }
        System.out.println(output);
    }

    public static String checkPalindrome(int l, int r, String s) {
        while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) {
            l--;
            r++;
        }
        String value = s.substring(l + 1, r);
        return value;


    }
}
