package string;

public class ValidPalindrome_LC125 {
    public static void main(String[] args) {
        String s = "A man, a plan, a canal: Panama";
//        String s = "0P";
//        String s = "race a car";
//        String s = " ";

        boolean result= isPalindrome(s);
        System.out.println(result);
    }
    public static boolean isPalindrome(String s) {
        s = s.toLowerCase();
        int l = 0;
        int r = s.length()-1;
        while(l<r){
            if(verifyItIsAlphabetorDigit(s.charAt(l))){
                if(verifyItIsAlphabetorDigit(s.charAt(r))){
                    if(s.charAt(l)==s.charAt(r)){
                        l++;r--;
                    }else{
                        return false;
                    }
                }else{
                    r--;
                }
            }else{
                l++;
            }
        }
        return true;
    }
    public static boolean verifyItIsAlphabetorDigit(char c){
        if(c -'a'>=0 && c-'a'<26 || c>='0' && c<='9') {
//            char x ='0';
//            System.out.println(x);
            return true;
        }
        return false;
    }
}
