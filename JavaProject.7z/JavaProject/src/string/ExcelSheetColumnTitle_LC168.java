package string;

public class ExcelSheetColumnTitle_LC168 {
    public static void main(String[] args) {
        int input = 729;
        int rem = input/26;
        int quo = input%26;
        System.out.println(rem);
        System.out.println(quo);
        char lc = (char)('A'+quo);
        System.out.println(lc);
    }
}
