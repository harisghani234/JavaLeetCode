package leetcode.string;

public class ReverseStringII_LC541 {
    public static void main(String[] args) {
        String s = "abcdefg";
        int k = 8;
        System.out.println(reverseStr(s,k));

    }

    public static String reverseStr(String s, int k) {
       String result = "";
       boolean ignore = true;
       int i = 0;
       while (i<s.length() && i+k<=s.length()){
           if(ignore) {
               StringBuilder sb = new StringBuilder(s.substring(i, i + k));
               sb.reverse();
               result = result + sb.toString();
               ignore = false;
               i=i+k;
           }else{
               result = result + s.substring(i, i+k);
               ignore = true;
               i=i+k;
           }

       }
       if(s.length()!=result.length()){
           result = result + s.substring(i,s.length());
       }

        return result;
    }

}
