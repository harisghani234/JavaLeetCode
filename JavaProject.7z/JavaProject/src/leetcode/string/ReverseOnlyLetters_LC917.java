package leetcode.string;

public class ReverseOnlyLetters_LC917 {
    public static void main(String[] args) {
//        String s = "ab-cd";
//        String s = "a-bC-dEf-ghIj";
//        String s = "Test1ng-Leet=code-Q!";
        String s = "7_28]";
        reverseOnlyLetters(s);
    }

    public static String reverseOnlyLetters(String s) {

        int l=0;
        int r = s.length()-1;
        StringBuffer sb = new StringBuffer(s);
        while(l<r){
            if(isChar(s.charAt(l)) && isChar(s.charAt(r))){
                char temp = s.charAt(l);
                sb.setCharAt(l,s.charAt(r));
                sb.setCharAt(r,s.charAt(l));
                l++;r--;
            }
            else if(isChar(s.charAt(r))==false){
                r--;
            }
            else if(isChar(s.charAt(l))==false){
                l++;
            }
        }
        System.out.println(sb.toString());
        return sb.toString();
    }

    public static boolean isChar(char c){
        if((c-'a'>=0 && c-'z'<=25) ||( c-'A'>=0 && c-'Z'<=25)){
            return true;
        }
        return false;
    }

}
