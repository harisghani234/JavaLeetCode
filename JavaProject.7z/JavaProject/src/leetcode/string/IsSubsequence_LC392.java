package leetcode.string;

public class IsSubsequence_LC392 {
    public static void main(String[] args) {
        String s = "acb";
        String t = "ahbgdc";
        System.out.println(isSubsequence(s,t));

    }

    public static boolean isSubsequence(String s, String t) {
//        boolean flag = false;
        int i =0;
        int j =0;
        while(i<s.length() && j<t.length()){
            if(s.charAt(i) == t.charAt(j)){
                i++;j++;
            }else{
                j++;
            }
        }
        System.out.println(i);
        if(i!=s.length()){
            return false;
        }
        return true;
    }
}
