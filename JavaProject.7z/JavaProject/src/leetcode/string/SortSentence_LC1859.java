package leetcode.string;

import java.util.Arrays;

public class SortSentence_LC1859 {
    //    Input: s = "is2 sentence4 This1 a3"
//    Output: "This is a sentence"
    public static void main(String[] args) {
        String input = "is2 sentence4 This1 a3";
        sortSentence(input);
    }

    public static String sortSentence(String s) {
        String [] input = s.split(" ");
        String [] output = new String[input.length];
        String finalOutput = "";

        for(int i=0; i<input.length;i++){
            char lastValue = input[i].charAt(input[i].length()-1);
            int index = lastValue - '0';
            output[index-1]= input[i].substring(0,input[i].length()-1);
        }
        for(int i=0; i<output.length;i++){
            finalOutput = finalOutput + output[i]+ " ";
        }
        finalOutput = finalOutput.trim();
        return finalOutput;
    }
}
