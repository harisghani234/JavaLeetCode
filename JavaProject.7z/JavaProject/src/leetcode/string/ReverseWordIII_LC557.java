package leetcode.string;

import java.lang.reflect.Array;
import java.util.Arrays;

public class ReverseWordIII_LC557 {
    public static void main(String[] args) {
        String s = "Let's take LeetCode contest";
        System.out.println(method1(s));
        System.out.println(method2(s));
    }

    /***
     * this method beats only 5%
     * @param s
     * @return
     */
    public static String method1(String s){
        String output = "";
        String[] word = s.split(" ");
        for(int i=0; i<word.length; i++){
            for(int j=word[i].length()-1; j>=0; j--){
                output = output+word[i].charAt(j);
            }
            output = output+ " ";
        }
        return output.trim();
    }
    /***
     * method using string buffer functions, beats 25%
     */
    public static String method2(String s){
        String output = "";
        String [] word = s.split(" ");
        for(int i =0; i<word.length; i++){
            StringBuffer sb = new StringBuffer(word[i]);
            sb = sb.reverse();
            output = output + sb.toString()+ " ";
        }
        return output.trim();
    }

}
