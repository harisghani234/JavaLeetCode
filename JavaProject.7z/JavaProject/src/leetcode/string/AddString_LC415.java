package leetcode.string;

public class AddString_LC415 {
    public static void main(String[] args) {
        String num1 = "11";
        String num2 = "123";
        System.out.println(addStrings(num1, num2));

    }
    public static String addStrings(String num1, String num2) {
        int output = 0;
        int n1 = Integer.parseInt(num1);
        int n2 = Integer.parseInt(num2);
        output = n1+n2;
        return String.valueOf(output);
    }
}
