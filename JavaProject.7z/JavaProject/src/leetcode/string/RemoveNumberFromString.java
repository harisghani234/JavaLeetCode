package leetcode.string;

public class RemoveNumberFromString {
    public static void main(String[] args) {
        String s = "Har1is Gh23a8n*&^i";
        usingASCII(s);
        System.out.println("\n******");
        usingWrapperClass(s);
    }

    public static void usingASCII(String s){
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)-'0'>=0 && s.charAt(i)-'9'<=9){
                System.out.print(s.charAt(i)+",");
            }
        }
    }
    public static void usingWrapperClass(String s){
        char [] arr = s.toCharArray();
        for(int i=0;i<arr.length;i++){
            if(Character.isDigit(arr[i])){
                System.out.print(arr[i]+ "," );
            }
        }
    }
}
