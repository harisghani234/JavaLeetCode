package leetcode.string;

public class ValidPalindromeII_LC680 {

    public static void main(String[] args) {
        String s = "aguokepatgbnvfqmgmlcupuufxoohdfpgjdmysgvhmvffcnqxjjxqncffvmhvgsymdjgpfdhooxfuupuculmgmqfvnbgtapekouga";
//        lcupupucul
        boolean result = validPalindrome(s);
        System.out.println(result);

    }

    public static boolean validPalindrome(String s) {
        int i = 0;
        int j = s.length() - 1;
        int count = 0;
        while (i <= j) {
            System.out.println("i is - "+ s.charAt(i));
            System.out.println("j is - "+ s.charAt(j));
            if (count > 1)
                return false;
            if (s.charAt(i) != s.charAt(j)) {
                j--;
                count++;
                if (count > 1)
                    return false;
                if (s.charAt(i) != s.charAt(j)) {
                    i++;
                    j++;
                    if (s.charAt(i) != s.charAt(j)) {
                        return false;
                    }
                }
            }
            i++;
            j--;
        }

        return true;
    }

}
