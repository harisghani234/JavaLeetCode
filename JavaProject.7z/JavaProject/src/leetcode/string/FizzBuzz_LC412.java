package leetcode.string;

import java.util.ArrayList;
import java.util.List;

public class FizzBuzz_LC412 {
    public static void main(String[] args) {
        int n = 15;
        System.out.println(fizzBuzz(n));

    }

    public static List<String> fizzBuzz(int n) {
        String s = "FizzBuzz";
        List<String> li = new ArrayList<>();
        for(int i=1; i<=n; i++){
            boolean fizz = false;
            boolean buzz = false;
            boolean fizzbuzz = false;
            if (i % 3 == 0) {
                fizz = true;
            }
            if(i % 5 == 0){
                buzz = true;
            }
            if(fizz && buzz){
                fizzbuzz = true;
                fizz = false;
                buzz = false;
            }
            if(fizz)
                li.add("Fizz");
            else if(buzz)
                li.add("Buzz");
            else if(fizzbuzz)
                li.add("FizzBuzz");
            else {
                li.add(String.valueOf(i));
            }
        }
        return li;

    }
}
