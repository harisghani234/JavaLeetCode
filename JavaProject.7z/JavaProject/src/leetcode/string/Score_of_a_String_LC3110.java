package leetcode.string;

public class Score_of_a_String_LC3110 {
    public static void main(String[] args) {
        String s = "hello";
        System.out.println(scoreOfString(s));
    }

    public static int scoreOfString(String s) {
        int sum=0;
        for(int i=0; i<s.length();i++){
            if((i+1)==s.length())
                break;
            int l = s.charAt(i);
            int r = s.charAt(i+1);
            if(l-r>0)
                sum=sum+(l-r);
            else
                sum = sum +(r-l);
        }
        return sum;
    }
}
