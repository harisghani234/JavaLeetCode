package leetcode.string;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class FindTheDifference_LC389 {
    public static void main(String[] args) {
        String s = "dcab";
        String t = "abcde";
        System.out.println(findTheDifference(s,t));
        System.out.println(usingArraysSort(s,t));
    }

    public static char findTheDifference(String s, String t) {
        char c = ' ';
        int [] arr = new int[26];
        for(int i=0; i<s.length();i++){
           int index = s.charAt(i)-'a';
           arr[index] = arr[index]+1;
        }
        for(int i=0; i<t.length();i++){
            int index = t.charAt(i)-'a';
            arr[index] = arr[index]-1;
        }
        for(int i=0; i<arr.length;i++){
            if(arr[i]<0){
                c = (char)('a'+i);
            }
        }

        return c;
    }

    /**
     * Hashset will not work for input s = a and t = aa
     * @param s
     * @param t
     * @return
     */
    public static char usingHashSet(String s, String t){
        char c = ' ';
        Set<Character> set = new HashSet<>();
        for(int i=0;i<s.length();i++){
            set.add(s.charAt(i));
        }
        for(int i=0; i<t.length();i++){
            if(set.add(t.charAt(i)))
                return t.charAt(i);
        }

        return c;
    }

    public static char usingArraysSort(String s, String t){
        char []sArray = s.toCharArray();
        char [] tArray = t.toCharArray();
        Arrays.sort(sArray);
        Arrays.sort(tArray);
        for(int i=0; i<tArray.length; i++){
            if(i==tArray.length-1)
                return tArray[i];
            if(tArray[i] != sArray[i]){
                return tArray[i];
            }
        }
        return ' ';
    }
}
