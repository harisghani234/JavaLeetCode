package leetcode.string;

import java.util.HashMap;

public class WordPattern_LC290 {
    public static void main(String[] args) {
//        String pattern = "aaa";
//        String s = "aa aa aa aa"; false
//        String pattern = "abba";
//        String s = "dog dog dog dog"; false
        String pattern = "abba";
        String s = "dog cat cat dog"; // true
        System.out.println(wordPattern(pattern, s));

    }

    public static boolean wordPattern(String pattern, String s) {
        String s_arr[] = s.split(" ");
        System.out.println(pattern.length());
        System.out.println(s_arr.length);
        System.out.println(s_arr.length != pattern.length());
        if(s.length()==0 || pattern.length()==0 || s_arr.length != pattern.length())
            return false;
        HashMap<Character, String> hmap = new HashMap<>();
        for(int i=0; i<s_arr.length; i++){
            if(hmap.containsKey(pattern.charAt(i))){
                if (!hmap.get(pattern.charAt(i)).equals(s_arr[i])){
                    return false;
                }
                // added this line to if the value like dog is already mapped to character a, then it should not be allowed to map to char b
                else if(hmap.containsValue(s_arr[i]) && !hmap.containsKey(pattern.charAt(i))){
                    return false;
                }
            }else{
                hmap.put(pattern.charAt(i), s_arr[i]);
            }
        }
        return true;
    }

}
