package leetcode.string;

import java.util.HashMap;

public class IsomorphicStrings_LC205 {
    public static void main(String[] args) {
        String s = "paper";
        String t = "title";
        System.out.println(isIsomorphic(s,t));

    }
    public static boolean isIsomorphic(String s, String t) {
        if(s.length()!=t.length())
            return false;
        HashMap<Character, Character> hmap = new HashMap<>();
        for(int i=0; i<s.length(); i++){
            if(hmap.containsKey(s.charAt(i))){
                // verify s.charAt(i) is == hamp.put(
                if(hmap.get(s.charAt(i))!= t.charAt(i)){
                    return false;
                }
            }
            else if(hmap.containsValue(t.charAt(i))){
                // then it must be equal to s.charAt(i)
                return false;
            }
            else{
                hmap.put(s.charAt(i), t.charAt(i));
            }
        }

        return true;
    }
}
