package leetcode.string;

import java.util.Arrays;

public class LongestCommonPerfix_LC14 {
    public static void main(String[] args) {
        String[] strs = {"flower", "flow", "flight"};
        System.out.println(longestCommonPrefix(strs));
    }

    public static String longestCommonPrefix(String[] strs) {
        String output = "";
        Arrays.sort(strs);
        int k = 0;
        String s1 = strs[0];
        String s2 = strs[strs.length - 1];
        while (s1.length() >= k && s2.length() >= k) {
            if (s1.charAt(k) == s2.charAt(k)) {
                output = output + s1.charAt(k);

            }else{
                break;
            }
            k++;
        }
//        return s1.substring(0,k);
//        or
        return s1.substring(0, k);
    }
}
