package leetcode.string;

import java.util.HashMap;
import java.util.Map;

public class LongestPalindrome_LC409 {
    public static void main(String[] args) {
        String s = "abccccdd";
        System.out.println(longestPalindrome(s));
        System.out.println(usingCharArray(s));

    }


    public static int longestPalindrome(String s) {
        HashMap<Character, Integer> hmap = new HashMap<>();
        int result =0;
        boolean flag = true;
        for(int i=0; i< s.length(); i++){
            if(hmap.containsKey(s.charAt(i)))
                hmap.put(s.charAt(i), hmap.get(s.charAt(i))+1);
            else
                hmap.put(s.charAt(i),1);
        }
        for(Map.Entry<Character, Integer> map : hmap.entrySet()){
            int value = map.getValue();
            if(value%2==0){
                result = result+value;
            }else{
//                if(value/2>1){
                    result = result + ((value/2)*2);
                    if(flag){
                        result++;
                        flag = false;
                    }
                }
//            }
        }
        return result;
    }
    public static int usingCharArray(String s) {
        int [] arr = new int[26];
        int result =0;
        boolean flag = true;
        for(int i=0; i< s.length(); i++){
           int index = s.charAt(i)-'a';
           arr[index] = arr[index]+1;
        }
        for(int i=0; i<arr.length; i++){
            if(arr[i]%2==0){
                result= result+arr[i];
            }else{
                result = result+((arr[i]/2)*2);
                if(flag){
                    result++;
                    flag = false;
                }
            }
        }
        return result;
    }

}
