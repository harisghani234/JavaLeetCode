package leetcode.string;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        String s = "Tomorrow";
//      Output= “T&m&&rr&&&w
        String output = "";
        int count =1;
        for(int i=0; i<s.length();i++){
            if(s.charAt(i) == 'o'){
                for(int j=0; j<count; j++){
                    output = output + '&';
                }
                count++;
            }else{
                output = output +s.charAt(i);
            }
        }
        System.out.println(output);

    }

}
