package leetcode;

import java.util.HashMap;
import java.util.Map;

public class Anagram {
    public static void main(String[] args) {
        //    Input: s = "anagram", t = "nagaram"
        String s = "anagram";
        String t = "nagaram";
        boolean status = isAnagram(s,t);
//        boolean status = usingHashmap(s, t);
        if (status)
            System.out.println("Anagram");
        else
            System.out.println("Not Anagram");
    }



    // best solution perf and memory wise
    public static boolean isAnagram(String s, String t) {
        if (s.length() != t.length())
            return false;
        if (s.length() == 0)
            return false;
        int[] arr = new int[26];
        for (int i = 0; i < s.length(); i++) {
            char sc = s.charAt(i);
            if (sc - 'a' >= 0 && sc - 'z' < 26) {
                int index = sc - 'a';
                arr[index] = arr[index] + 1;
            }
        }

        for (int i = 0; i < t.length(); i++) {
            char tc = t.charAt(i);
            if (tc - 'a' >= 0 && tc - 'z' < 26) {
                int index = tc - 'a';
                arr[index] = arr[index] - 1;
            }
        }

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > 0)
                return false;
        }
        return true;
    }

    public static boolean usingHashmap(String s, String t) {
        if (s.length() == 0)
            return false;
        if (s.length() != t.length())
            return false;
        HashMap<Character, Integer> hmap = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            if (hmap.containsKey(s.charAt(i))) {
                hmap.put(s.charAt(i), hmap.get(s.charAt(i)) + 1);
            } else {
                hmap.put(s.charAt(i), 1);
            }
        }
        System.out.println(hmap);
        for (int i = 0; i < t.length(); i++) {
            if (hmap.containsKey(t.charAt(i))) {
                hmap.put(t.charAt(i), hmap.get(t.charAt(i)) - 1);
            } else {
                return false;
            }
        }
        System.out.println(hmap);
        for(Map.Entry<Character,Integer> i: hmap.entrySet()){
            if(i.getValue()>0)
                return false;
        }
        return true;
    }
}
