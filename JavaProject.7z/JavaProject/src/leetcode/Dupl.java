package leetcode;

import java.util.Set;
import java.util.TreeSet;

public class Dupl {
    public static void main(String[] args) {
        int [] arr = {1,3,5,3,5,2,5,6,7,8,24,23,32,32,23,24,4,2,99,101};
        Set<Integer> set = new TreeSet<>();
        for( int i=0; i<arr.length; i++){
           set.add(arr[i]);
        }
        System.out.println(set);
    }
}
