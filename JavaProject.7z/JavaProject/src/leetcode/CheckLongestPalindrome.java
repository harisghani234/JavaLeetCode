package leetcode;

import java.util.Arrays;

public class CheckLongestPalindrome {
    public static void main(String[] args) {
        String[] str = {"flower", "flow", "flight"};
//        System.out.println(Arrays.toString(str));
        // prefix means the first and last would have common characters and between all the elements would have atleast that character
        System.out.println(checklongestprefix2(str));

    }

    //approach 1, 7ms to run the program
    public static String checklongestprefix(String[] arr) {
        if (arr.length == 0)
            return "";
        if (arr.length == 1)
            return arr[0];
        String output = "";
        Arrays.sort(arr);
        String first = arr[0];
        String last = arr[arr.length - 1];
        for (int i = 0; i < first.length(); i++) {
            if (first.charAt(i) == last.charAt(i)) {
                output = output + first.charAt(i);
            } else {
                return output;
            }

        }
        return output;
    }

    //approach 2, 0ms to run the program
    public static String checklongestprefix2(String[] arr) {
        if (arr.length == 0)
            return "";
        if (arr.length == 1)
            return arr[0];
        Arrays.sort(arr);
        String first = arr[0];
        String last = arr[arr.length - 1];
        int index = 0;
        while(index<first.length() && index<last.length()){
            if(first.charAt(index)==last.charAt(index)){
                index++;
            }else{
                break;
            }
        }
        return first.substring(0,index);

    }
}
