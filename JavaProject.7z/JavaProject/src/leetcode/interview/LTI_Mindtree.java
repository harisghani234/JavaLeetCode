package leetcode.interview;

import java.util.*;

public class LTI_Mindtree {
    public static void main(String[] args) {
        int arr[]= {43,23,53,12,55,0,35,94,0,2,29,58,12,8};
//        findDuplicate(arr);
//        reverseArray(arr);
//        secondLargestNumber(arr);
//        findSum(arr, 35);
        System.out.println(isValid("()[]{({})"));

    }
    public static void findDuplicate(int []arr){
        Set<Integer> set = new HashSet<>();
        ArrayList<Integer> al = new ArrayList<>();
        for(int i =0; i<arr.length; i++){
            if(!set.add(arr[i])){
                al.add(arr[i]);
            }
        }
        System.out.println(al);
    }
    public static void reverseArray(int [] arr){
        for(int i=0; i<arr.length/2; i++){
            int temp = arr[i];
            arr[i]=arr[arr.length-1-i];
            arr[arr.length-1-i] = temp;
        }
        System.out.println(Arrays.toString(arr));
    }
    public static void secondLargestNumber(int[] arr){
        int max = arr[0];
        int secondMax = arr[1];
        if(secondMax>max){
            max = arr[1];
            secondMax = arr[0];
        }
        for(int i =2; i<arr.length; i++){
            if(arr[i]>max){
                secondMax = max;
                max = arr[i];
                continue;
            }
            if(arr[i]>secondMax){
                secondMax = arr[i];
            }
        }
        System.out.println(max);
        System.out.println(secondMax);

    }
    public static void findSum(int [] arr, int target){
        HashMap<Integer, Integer> hmap = new HashMap<>();
        for(int i=0; i<arr.length; i++){
            hmap.put(arr[i],i);
        }
        for(int i=0; i<arr.length; i++){
            int findValue = arr[i]-target;
            if(hmap.containsKey(findValue)) {
                System.out.println("one key is - "+arr[i]+ " and second key is - "+findValue);
                System.out.println(arr[i]+ " - is found at - "+i+ " whereas second key is found at - "+"");
            }
        }
    }

    public static boolean isValid(String s) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '(' || s.charAt(i) == '{' || s.charAt(i) == '[') {
                stack.push(s.charAt(i));
                continue;
            }
            if(s.charAt(i)==')') {
                if(stack.pop() != '(')
                    return false;
            }
            if(s.charAt(i)=='}') {
                if(stack.pop() != '{')
                    return false;
            }
            if(s.charAt(i)==']') {
                if(stack.pop() != '[')
                    return false;
            }
        }
        return true;
    }
}
