package leetcode.interview;

public class ValueLabs {
    public static void main(String[] args) {
        String s = "This is a Test";
        // . int [26]
        int[] arr = new int[26];
        for(int i=0; i<s.length();i++){
            if(isChar(s.charAt(i))){
                int index = s.charAt(i)-'a';
                arr[index] = arr[index]+1;
            }
        }
        for(int i=0; i<s.length();i++){
            if(isChar(s.charAt(i))){
                int index = s.charAt(i)-'a';
                if(arr[index]==1){
                    System.out.println(s.charAt(i));
                    break;
                }
            }
        }
    }
    public static boolean isChar(char c){
        if(c-'a'>=0 && c-'a'<26){
            return true;
        }
        return false;
    }

}
