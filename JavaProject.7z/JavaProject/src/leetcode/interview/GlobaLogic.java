package leetcode.interview;

import java.util.HashMap;
import java.util.Map;

public class GlobaLogic {
    public static void main(String[] args) {
     round2();

    }


    public static void round2(){
        {
            String input= "aabbbccccaaac";
            StringBuilder compressed = new StringBuilder();

            int i = 1;
            int count = 1;
            char character = input.charAt(0);

            while(i<=input.length()){
                if(i==input.length()){
                    compressed.append(character).append(count);
                    break;
                }
                if(character == input.charAt(i)){
                    count++;
                    i++;
                }else{
                    compressed.append(character).append(count);
                    count = 1;
                    character = input.charAt(i);
                    i++;
                }

            }
            System.out.println(compressed);

        }



    }
    public static void round1(){
        int [] array = {5,9,7,61,18,99,36,45};
        int max = array[0];
        int secondMax = array[1];
        if(max<secondMax){
            max = array[1];
            secondMax = array[0];
        }
        for(int i=2; i<array.length; i++) {
            if (array[i] > max) {
                secondMax = max;
                max = array[i];
            } else if (array[i] > secondMax && array[i] < max) {
                secondMax = array[i];
            }
        }
        System.out.println(secondMax);
    }
}
