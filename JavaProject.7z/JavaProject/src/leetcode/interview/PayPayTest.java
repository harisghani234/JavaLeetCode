package leetcode.interview;

public class PayPayTest {
    // add all elements but ignore those who come between 6 and 9 ignoring 6 and 9.
    public static void main(String[] args) {
//       int [] sum69 = {1,5,9}; // output = 15
//        int [] sum69 = {1,3, 6,2,9}; // output  = 4
//        int [] sum69 = {1,3, 6,2,9, 5}; // output  = 9
//        int [] sum69 = {1,3, 2,9}; // output  = 15
        int [] sum69 = {1,3,10,6,6}; // output  = 14
        int sum = 0;
        boolean flag = true;
        for(int i =0; i<sum69.length; i++){
            if(flag){
                if(sum69[i]!= 6){
                    sum = sum +sum69[i];
                }else{
                    flag = false;
                }
            }else{
                if(sum69[i]==9){
                    flag = true;
                }

            }
        }
        System.out.println(sum);
    }
}
