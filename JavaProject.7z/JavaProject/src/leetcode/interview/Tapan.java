package interview;

public class Tapan {
    public static void main(String[] args) {
        String s = "we@l*c&om^e";
        StringBuffer test = new StringBuffer(s);
//        output: em@o*c&le^w
        int l = 0;
        int r = test.length()-1;
        while(l<r){
            if(!(test.charAt(l)>='a' && test.charAt(l)<='z'))
                l++;
            else if(!(test.charAt(r)>='a' && test.charAt(r)<='z'))
                r--;
            else if(test.charAt(l)>='a' && test.charAt(l)<='z' && test.charAt(r)>='a' && test.charAt(r)<='z') {
                char temp = test.charAt(l);
                test.setCharAt(l, test.charAt(r));
                test.setCharAt(r, temp);
                l++;
                r--;
            }
        }
        System.out.println(test);
    }
}
