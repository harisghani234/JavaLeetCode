package leetcode.interview;

class GridSystems {
    public static void main(String[] args) {
        int s= 51525233;
//        System.out.println(isMyTicketLucky(s));
        System.out.println(checkIfTicketIsLucky(s));
    }
//    public static boolean isMyTicketLucky(int ticketNumber) {
//        int temp = ticketNumber;
//        int firstSum = 0;
//        int lastSum = 0;
//        int count = 1;
//        while (temp > 0) {
//            int rem = temp % 10;
//            if (count > 3) {
//                lastSum = lastSum + rem;
//            } else {
//                firstSum = firstSum + rem;
//            }
//            count++;
//            temp = temp / 10;
//        }
//        if (firstSum != lastSum) {
//            return false;
//        }
//        return true;
//    }

    public static boolean checkIfTicketIsLucky(int ticketNumber){
        int firstHalfSum=0,lastHalfSum = 0;
        int temp = ticketNumber;
        // to find the length of the integer
        String s = Integer.toString(ticketNumber);
        int halfLen = s.length()/2;
        while(temp>0){
            int rem = temp%10;
            if(halfLen>0){
                lastHalfSum = lastHalfSum + rem;
            }else{
                firstHalfSum = firstHalfSum +rem;
            }
            halfLen --;
            temp = temp/10;
        }
        if(firstHalfSum != lastHalfSum)
            return false;
        return true;
    }
}