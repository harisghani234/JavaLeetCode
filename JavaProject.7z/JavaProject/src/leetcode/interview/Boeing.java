package leetcode.interview;

public class Boeing {
    public static void main(String[] args) {
// *
// **
// ***
// ****
        for(int i =0; i<=4; i++){
            for(int j=0; j<i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
        select_dropdown("haris");
        select_dropdown(2);
    }

    public static void select_dropdown(String s){
        System.out.println("string");
    }
    public static void select_dropdown(int index){
        System.out.println(index);
    }
}
