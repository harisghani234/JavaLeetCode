//package leetcode.interview;
//
//public class Apexon2 {
//    public static void main(String[] args) {
//        /**
//         * /*
//         *  * Click `Run` to execute the snippet below!
//         *  */
//         *
//         * import java.io. *;
//         * import java.util. *;
//         *
//         * /*
//         *
//         * You are given a 2D board('N' rows and 'M' columns) of characters and a list of 'words'.
//         *
//         *
//         *
//         * Your task is to return word list if the given word exists in the grid. The word can be constructed from letters of sequentially adjacent cells, where adjacent cells are horizontally or vertically neighboring.
//         *
//         *
//         *
//         * Note:
//         * The same letter cell should not be used more than once.
//         * For Example:
//         * For a given word “design” and the given 2D board
//         * [['e’, ‘a’, ‘t’, ‘h’],
//         *  [‘d’, ‘e’, ‘s’, ‘i’],
//         *  [‘d’, ‘g’, ‘f’, ‘g’],
//         *  [‘e’, ‘c’, ‘p’, ‘n’]]
//         *
//         *
//         *   word list : ["design", "pea", "eat", "rain"]
//         *
//         *   ans: ["design", "eat"]
//         *
//         *
//         *  */
//         *
//         *
//         *  /*
//         *
//         *  Group similar words together
//         *
//         * I/p: ["eat", "tea", "tan", "ate", "nat", "bat"]
//         *
//         * O/P [ ["bat"], ["nat","tan"], ["ate", "eat", "tea"] ]
//         *
//         *
//         *   */
//         *
//         *class Solution {
//         *
//
//            public static void main(String[] args) {
//         *
//         *    // output -> List<List<String>>
//         *String[] array = {"eat", "tea", "tan", "ate", "nat", "bat"};
//         *
//         *
//         *HashMap<String, List<String>> hmap = new HashMap<>();
//         *
//         *for (int i = 0; i < array.length; i++) {
//         *char[] sortedWord = array[i].toCharArray();
//         *Arrays.sort(sortedWord);
//         *
//         *String s = Arrays.toString(sortedWord);
//         *
//         *String sortedWord1 = createString(sortedWord);
//         *
//         *System.out.println(s.toString());
//         *
//         *if (hmap.containsKey(sortedWord1)) {
//         *List<String> li2 = hmap.get(sortedWord1);
//         *li2.add(array[i]);
//         *hmap.put(sortedWord1, li2);
//         *} else {
//         *List<String> li = new ArrayList<>();
//         *li.add(array[i]);
//         *hmap.put(sortedWord1, li);
//         *       // hmap.get(sortedWord.toString()).add(array[i]);
//         *}
//         *}
//         *
//         *
//         *
//         *   // }
//         *System.out.println(hmap);
//         *}
//         *
//                 *
//
//            public static String createString(char[] array) {
//         *String output = "";
//         *for (int i = 0; i < array.length; i++) {
//         *output = output + array[i];
//         *}
//         *
//         *return output;
//         *}
//         *
//        }
//         *
//         *
//         *
//         * // Your previous Plain Text content is preserved below:
//         *
//         * // This is just a simple shared plaintext pad, with no execution capabilities.
//         *
//         * // When you know what language you'd like to use for your interview,
//         * // simply choose it from the dots menu on the tab, or add a new language
//         * // tab using the Languages button on the left.
//         *
//         * // You can also change the default language your pads are created with
//         * // in your account settings: https://app.coderpad.io/settings
//         *
//         * // Enjoy your interview!
//         */
//    }
//}
