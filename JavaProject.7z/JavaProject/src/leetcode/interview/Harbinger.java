package leetcode.interview;

public class Harbinger {
    public static void main(String[] args) {

    }
}
