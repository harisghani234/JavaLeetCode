package interview;

import java.util.*;

public class WallmartTest {

    public static void main(String[] args) {

        Integer score = getScore();


        System.out.println(WallmartTest.gameEndMessage("", 70 ,score ));

    }

    public static String gameEndMessage(String alias, Integer score, Integer attempts) {
        try {
            if (Objects.isNull(alias) || alias.equalsIgnoreCase("")
            ) {
                return "Please enter proper name";
            }
            return "Hi " + alias + ", your average score is " + score / attempts;

        } catch (ArithmeticException exception) {
            return "Oh! something wrong with your numbers";
        } catch (Exception e) {
            return "Could not fetch, your score";
        }
    }

    //
    public static Integer getScore() {
        return 0;
    }



    // Testcase 1 : “alpha”, 500,10  -> “Hi alpha your average score is 50”
    // testcase2 : "alpha", 20, 0 -> Oh! something wrong with your numbers
    // test case3 : [alpha], 50, null -> Could not fetch, your score
    // test case4: "", 500,39 ->Please enter proper name
}
