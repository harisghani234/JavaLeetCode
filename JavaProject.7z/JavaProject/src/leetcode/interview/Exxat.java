package leetcode.interview;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Exxat {
    public static void main(String[] args) {
//        String input = "I am a Software Engineer";
//        round1(input);
//        round2("sd");
//        round2_2();

        String s = "Sap9ent";
        char[] c = s.toCharArray();
        System.out.println(Character.isDigit(c[2]));
    }

    public static void round1(String input) {
        StringBuffer sb = new StringBuffer(input);
        int l = 0;
        int r = input.length() - 1;
        while (l < r) {
            char lc = input.charAt(l);
            char rc = input.charAt(r);
            if (lc != ' ' && rc != ' ') {
                sb.setCharAt(l, rc);
                sb.setCharAt(r, lc);
                l++;
                r--;
                continue;

            } else if (lc == ' ' && rc != ' ') {
                l++;
                continue;
            } else if (lc != ' ' && rc == ' ') {
                r--;
                continue;
            } else {
                l++;
                r--;
            }

        }
//        while (l < r) {
//            char lc = input.charAt(l);
//            char rc = input.charAt(r);
//            if ((lc - 'a' >= 0 && lc - 'a' < 26 || lc - 'A' >= 0 && lc - 'a' < 26) && (rc - 'a' >= 0 && rc - 'a' < 26 || rc - 'A' >= 0 && rc - 'a' < 26)
//            ) {
//                sb.setCharAt(l, rc);
//                sb.setCharAt(r, lc);
//                l++;
//                r--;
//                continue;
//
//            } else if (!(lc - 'a' >= 0 && lc - 'a' < 26 || lc - 'A' >= 0 && lc - 'a' < 26) && (rc - 'a' >= 0 && rc - 'a' < 26 || rc - 'A' >= 0 && rc - 'a' < 26)){
//                l++;
//                continue;
//            }else if ((lc - 'a' >= 0 && lc - 'a' < 26 || lc - 'A' >= 0 && lc - 'a' < 26) && !(rc - 'a' >= 0 && rc - 'a' < 26 || rc - 'A' >= 0 && rc - 'a' < 26)){
//                r--;
//                continue;
//            }else{
//                l++;
//                r--;
//            }
//
//        }

//        both approach is fine
        System.out.println(sb);
    }

    public static void round2(String input) {
        String str = "Haris has interview";
        StringBuffer sb = new StringBuffer(" ");
//        o/p = "siraH sah weivretni"
        String[] word = str.split(" ");

        for (int i = 0; i < word.length; i++) {

            for (int j = word[i].length() - 1; j >= 0; j--) {
                char c = word[i].charAt(j); //s
                sb.append(c);
            }
            sb.append(" ");
        }
        System.out.println(sb);
    }

    public static void round2_2() {
        int[] arr1 = {2, 5, 6, 8, 9, 0, 0, 0};
        int[] arr2 = {1, 3, 4};
        int p1 = arr1.length - arr2.length - 1;
        int p2 = arr2.length - 1;
        int k = arr1.length - 1;

        while (p2 >= 0) {
            if (p1 >= 0 && arr1[p1] > arr2[p2]) {
                arr1[k] = arr1[p1];
                k--;
                p1--;
            } else {
                arr1[k] = arr2[p2];
                p2--;
                k--;
            }

        }
        System.out.println(Arrays.toString(arr1));

    }


}
