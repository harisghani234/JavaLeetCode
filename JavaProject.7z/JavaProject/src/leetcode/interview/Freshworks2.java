package leetcode.interview;

import java.util.HashMap;

public class Freshworks2 {
    // 1. Move all zeros to last of array
    // 2. {1,2,5,5,4,4,4} - print numbers which are duplicates and print numbers which are missing
    // e.g Duplicate 4 and 5, missing 3,6,7 as the length is 7
    // switch to frame with code
    // parse complex response
    public static void main(String[] args) {
        int[] array = {0, 5, 0, 0, 1, 9, 3, 4, 0, 3, 0, 0};
        moveAllZeros(array);
        System.out.println("****************************");
        int [] array2 = {1,2,5,5,4,4,4};
        printDuplicateAndMissing(array2);

    }

    public static void moveAllZeros(int[] array) {
        int k = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] != 0) {
                array[k++] = array[i];
            }
        }
        for (int i = k; i < array.length; i++) {
            array[i] = 0;
        }
        for (int a : array) {
            System.out.print(a + ",");
        }

    }

    public static void printDuplicateAndMissing(int [] array) {
        HashMap<Integer, Integer> hmap = new HashMap<>();
        for (int i = 0; i < array.length; i++) {
            if (hmap.containsKey(array[i])) {
                hmap.put(array[i], hmap.get(array[i]) + 1);
            } else {
                hmap.put(array[i], 1);
            }
        }

        for(int i=1; i<=array.length; i++){
            if(hmap.containsKey(i)){
                if(hmap.get(i)>1)
                    System.out.println("Duplicate Numbers in array - "+i);
            }else{
                System.out.println("Missing number is - "+i);
            }
        }
    }
}
