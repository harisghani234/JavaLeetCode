package leetcode.interview;

public class PayPay2 {
    public static void main(String[] args) {
//        int[] ara
    }

    public void method1(int array[]){

    }
}
