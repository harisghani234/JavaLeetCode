package leetcode.interview;

public class Diligent {
    public static void main(String[] args) {
//        System.out.println("hello");
//        Input1: coins[] = {1, 15, 10, 5}, Amount = 30
        //Input1: coins[] = {10, 10, 10, 10, 10}
//·       Output1: Minimum 3 coins required We can use one coin of Rs.15, one of Rs.10 and one of Rs.5

        int array[] = {10, 2, 15, 2, 23, 90, 67};
//·       Output: 20 or 90
        int i = 1;
        if(array.length == 1){
            System.out.println("peek element is - "+array[0]);
        }else{
            while(i<array.length){
                if(i==array.length){
                    break;
                }
                int leftVal = i-1;
                int rightVal = i+1;
                if(array[i]>array[leftVal] && array[i]>array[rightVal]){
                    System.out.println("Peek element - "+ array[i]);
                    i++;
                }else{
                    i++;
                }
            }

        }




    }

//    public static int peekElement(int []a){
//
//
//
//
//    }
}
