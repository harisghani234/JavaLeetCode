package leetcode;

import java.util.HashMap;
import java.util.Map;

public class Occurance {
    public static void main(String[] args) {
        int [] array = {29,0,32,3,52,4,0,29,3,29,3,3,52,52,52};
        Occurance.occuranceInArray(array);
        String var = "myNameiNmdesammmmm";
        Occurance.occuranceInString(var);

    }

    public static void occuranceInArray(int [] arr){
       HashMap<Integer, Integer> hmap = new HashMap<>();
       for(int i=0;i<arr.length; i++){
           if(hmap.containsKey(arr[i])){
               hmap.put(arr[i], hmap.get(arr[i])+1);
           }else{
               hmap.put(arr[i],1);
           }
       }
        for(Map.Entry<Integer,Integer> i: hmap.entrySet()){
            System.out.println("Key is - "+i.getKey() + " and its value is - "+i.getValue());
        }
    }

    public static void occuranceInString(String str){
        HashMap<Character, Integer> hm = new HashMap<>();
        char [] arr = str.toCharArray();
        for(int i=0; i<arr.length;i++){
            if(hm.containsKey(arr[i])){
                hm.put(arr[i],hm.get(arr[i])+1);
            }
            else{
                hm.put(arr[i],1);
            }
        }
        for(Map.Entry<Character, Integer> i: hm.entrySet()){
            System.out.println("Key - "+i.getKey() +" value - "+i.getValue());
        }

    }

}
