package leetcode;

import java.util.HashMap;
import java.util.Map;

public class HashmapBasics {
    public static void main(String[] args) {
        // if you add duplicate key, it would replace the current key with new one
        //it allows to store the null keys as well
        // order is not preserved, for order LinkedHashMap has to be userd
        // Demerit of hashmap - Thread-unsafe: HashMaps are not thread-safe, which means that if multiple threads access the same hashmap simultaneously, it can lead to data inconsistencies. If thread safety is required, ConcurrentHashMap can be used.


        HashMap<String, Integer> hmap = new HashMap<>();
//      LinkedHashMap<String, Integer> hmap = new LinkedHashMap<>();
        hmap.put("haris", 1);
        hmap.put("Ghani", 2);
        hmap.put("Aquil", 3);
        hmap.put("Hammad", 4);
        // get the size
        System.out.println(hmap.size());
        // fetch element
        System.out.println(hmap.get("Hammad"));
        //check if element is present
        if(hmap.containsKey("haris")){
            System.out.println(hmap.get("haris"));

        }
        //removing element
        hmap.remove("Ghani");
//        System.out.println(hmap);
        System.out.println(hmap.containsKey("Ghani"));
        // traversal
        for(Map.Entry<String,Integer> i: hmap.entrySet()){
            System.out.println("key is "+i.getKey() +"  and its value is - "+i.getValue());
        }
        System.out.println(hmap.containsValue(4));
    }
}
