package leetcode.array;

import java.util.Arrays;

/**
 * this is about array rotation program with basic logics for left rotation
 */
public class RotateArray {
    public static void main(String[] args) {
        int [] a = {1,2,3,4,5,6};
        int d = 2;
        method1(a, d);
    }

    /**
     * Approach1 - using temp array which takes extra space
     * @param nums
     * @param d
     */
    public static void method1(int [] nums, int d){
        int [] output = new int[nums.length];
        int k =0;
        for(int i = d; i<nums.length; i++) {
            output[k++] = nums[i];
        }
        for( int i =0; i<d; i++){
            output[k++] = nums[i];
        }
        System.out.println(Arrays.toString(output));
    }

    /**
     * using inbuilt reverse function three times
     */
    public static void method2(int [] nums, int d){
//        Arrays.sort();
    }
}
