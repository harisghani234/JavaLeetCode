package leetcode.array;

public class R {
    public static void main(String[] args) {
        int [] array = {2,5,0,4,0,52,0,4,0};
        int temp = 0;
        for(int i=0; i<array.length;i++){
            if(array[i]!=0)
                array[temp++]=array[i];
        }
        for(int i=temp;i< array.length;i++){
            array[i]=0;
        }

        for(int a: array){
            System.out.println(a);
        }


    }
}
