package leetcode.array;

import java.util.Arrays;

public class DutchNationalFlagProblem {
    public static void main(String[] args) {
        //Sort an array of 0s, 1s and 2s | Dutch National Flag problem
        int [] arr = {0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1};
        int count0=0, count1=0, count2=0;
        for(int i=0;i<arr.length;i++){
            if(arr[i]==0){
                count0++;
            }else if(arr[i]==1){
                count1++;
            }else{
                count2++;
            }
        }
        // first approach
//        int temp =0;
//        while (temp<count0){
//            arr[temp++]=0;
//        }
//        while (temp<(count1+count0)){
//            arr[temp++]=1;
//        }
//        while (temp<(count1+count0+count2)){
//            arr[temp++]=2;
//        }

        // second approach
        int test = count0+count1+count2;
        for(int i=0;i<test;i++){
            if(count0!=0){
                arr[i]=0;
                count0--;
            }else{
                if(count1!=0){
                    arr[i]=1;
                    count1--;
                }else{
                    arr[i]=2;
                    count2--;
                }
            }
        }

        System.out.println(Arrays.toString(arr));
    }
    public boolean isSubsequence(String s, String t) {
        if(!(s.length()>0 && t.length()>0))
            return false;
        int temp_len_s =0;
        for(int i=0;i<t.length();i++)
            if(t.charAt(i)==s.charAt(temp_len_s)){
                temp_len_s++;
            }
        if(temp_len_s==s.length())
            return true;
        return false;

    }
}
