package leetcode.array;

import java.util.HashSet;
import java.util.Set;

public class ContainsDuplicate_LC217 {
    public static void main(String[] args) {
//        int [] arr = {1,1,1,3,3,4,3,2,4,2};
        int [] arr = {1,2,3,1};
        System.out.println(containsDuplicate(arr));


    }
    public static boolean containsDuplicate(int[] nums) {
        Set<Integer> set = new HashSet<>();
        for(int i=0;i<nums.length; i++){
            if(set.add(nums[i])==false)
                return true;
        }
        return false;
    }

}
