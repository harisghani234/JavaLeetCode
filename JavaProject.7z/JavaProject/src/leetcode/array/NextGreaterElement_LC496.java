//package leetcode.array;
//
//public class NextGreaterElement_LC496 {
//    public static void main(String[] args) {
//
//    }
//
//    public static int[] nextGreaterElement(int[] nums1, int[] nums2) {
//
//    }
//
//    public static void createGreaterElement(int [] nums){
//        int n [] = new int[nums.length];
//        n[nums.length-1] = -1;
//        int k =0;
//        for(int i=1; i<nums.length-1; i++){
//            if(nums[i]>nums[i-1]){
//                nums[k++]=nums[i];
//            }else{
//
//            }
//        }
//    }
//}
