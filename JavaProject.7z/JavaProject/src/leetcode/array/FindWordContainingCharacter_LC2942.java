package leetcode.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FindWordContainingCharacter_LC2942 {
    public static void main(String[] args) {
        String[] arr = {"Leet", "Code"};
        char c = 'e';
        System.out.println(findWordsContaining_approach2(arr, c));

    }

    public static List<Integer> findWordsContaining(String[] words, char x) {
        List<Integer> al = new ArrayList<>();

        for (int i = 0; i < words.length; i++) {
            for (int j = 0; j < words[i].length(); j++) {
                if (words[i].charAt(j) == x) {
                    al.add(i);
                    break;
                }
            }
        }
        return al;
    }

    public static List<Integer> findWordsContaining_approach2(String[] words, char x) {
        ArrayList<Integer> al = new ArrayList<>();

        for (int i = 0; i < words.length; i++) {
            if (words[i].indexOf(x) != -1) {
                al.add(i);
//                continue;
            }
        }
        return al;
    }
}
