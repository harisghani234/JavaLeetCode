package leetcode.array;

public class MajorityElement_LC169 {
    public static void main(String[] args) {
        int[] arr = {2, 2, 1, 1, 1, 2, 2};
        System.out.println(majorityElement(arr));

    }

    public static int majorityElement(int[] nums) {
        int count =0;
        for(int i=0;i<nums.length;i++){


        }
        return count;
    }
}
