package leetcode.array;

public class BuySellStock_LC121 {
    public static void main(String[] args) {
        int [] prices = {7,1,5,3,6,4};
//        int [] prices = {7,6,4,3,1};
        bruteForceMethod(prices);
    }

    public static void bruteForceMethod(int [] prices){
        int min = 0;
        int max = 0;
        int profit = 0;
        for(int i =0; i<prices.length; i++){
            min = prices[i];
            for(int j=i+1; j<prices.length; j++){
                max = prices[j];
                if(max>min){
                    if(max-min > profit){
                        profit = max-min;
                    }
                }
            }
        }
        System.out.println(profit);
    }

    public static void bruteForceMethod2(int [] price){
        int best = 0;
        int buyDay = 0;
        int sellDay = 0;
        for(int i=0; i<price.length; i++){
            for(int j=i+1; j<price.length;j++){
                if(price[j]>price[i]) {
                    if(best<=price[j]-price[i]) {
                        buyDay = i;
                        sellDay = j;
                        best = price[j] - price[i];
                    }
                }
            }
        }
        System.out.println(best);
        System.out.println(buyDay);
        System.out.println(sellDay);
    }
}
