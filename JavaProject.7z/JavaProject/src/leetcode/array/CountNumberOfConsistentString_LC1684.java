package leetcode.array;

import java.util.Arrays;
import java.util.HashSet;

public class CountNumberOfConsistentString_LC1684 {
    public static void main(String[] args) {
     String [] word = {"ad", "bd", "aaab", "baa", "badab"};
     String allowed = "ab";
     System.out.println(countConsistentStrings(allowed, word));
    }
    public static int countConsistentStrings(String allowed, String[] words) {
        int result = 0;
        boolean [] allowedMapping = new boolean[26];
        for(int i =0; i<allowed.length(); i++){
            allowedMapping[allowed.charAt(i)-'a'] = true;
        }

        for(int i =0; i<words.length; i++){
            boolean flag = true;
            for(int j=0; j<words[i].length(); j++){
                int index = words[i].charAt(j)-'a';
                if(!allowedMapping[index]){
                    flag = false;
                    break;
                }
            }
            if(flag){
                result++;
            }
        }

        return result;
    }
}
