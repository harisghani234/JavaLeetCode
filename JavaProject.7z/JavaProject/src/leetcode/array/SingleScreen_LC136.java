package leetcode.array;

import java.util.Arrays;

public class SingleScreen_LC136 {

    public static void main(String[] args) {
        int[] nums = {2,2,1};
        System.out.println(singleNumber(nums));
    }

    public static int singleNumber(int[] nums) {
        Arrays.sort(nums);
        int l =0;
        int r = nums.length-1;
        while (l<=r){
            if(nums[l] == nums[l+1]){
                l=l+2;
            }else{
                return nums[l];
            }
        }

        return nums[r];

    }
}


