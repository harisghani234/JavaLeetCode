package leetcode.array;

public class MergeSortedArray {
    public static void main(String[] args) {
        int[] nums1 = {1, 2, 5, 9, 7, 19};
        int[] nums2 = {1, 2, 4, 5};
        int[] numOutput = new int[nums1.length + nums2.length];
        int i=0,j=0,k=0;

        if(nums1.length<nums2.length){
            while (i<nums1.length){
                if(nums1[i]>nums2[j]){
                    numOutput[k++] = nums2[j++];
                }else{
                    numOutput[k++] = nums1[i++];
                }

            }
            while(j<nums2.length){
                numOutput[k++] = nums2[j++];
            }

        }else{
            while (j<nums2.length){
                if(nums1[i]>nums2[j]){
                    numOutput[k++] = nums2[j++];
                }else{
                    numOutput[k++] = nums1[i++];
                }
            }
            while(i<nums1.length){
                numOutput[k++] = nums1[i++];
            }

        }

        for(int a: numOutput){
            System.out.println(a);
        }
    }
}
