package leetcode.array;

import java.util.Arrays;

public class MoveZeroes_LC383 {
    public static void main(String[] args) {
        int[] arr = {0, 0, 1, 0, 3, 12, 4, 6, 87, 0, 7, 0};
//        System.out.println(Arrays.toString(arr));
//        moveZeroes(arr);
         moveZerosToLeft(arr);

    }

    public static void moveZeroes(int[] nums) {
        // create a temp variable of value 0 as array index starts with 0.
        // start iteration, if arr value at i is 0 then ignore otherwise add to arr[temp] and add temp by 1
        // with above we can get the count of all non-zero numbers in temp and shift all non-zero to start of arr
        // now from the temp value to array length value put all value as 0
        int temp =0;
        for(int i=0; i<nums.length; i++){
            if(nums[i]!=0){
                nums[temp++] = nums[i];
            }
        }
        for(int i=temp; i<nums.length; i++){
            nums[i]=0;
        }
        System.out.println(Arrays.toString(nums));
    }
    // move zero to left and other in correct order to right
    public static void moveZerosToLeft(int [] nums){
        int countZero = 0;
        int varNonZero = nums.length-1;
        // with this method i count find the number of zeros in arrya and place all non zero at correct order
        for(int i = nums.length-1; i>=0; i--){
            if(nums[i]!=0){
                nums[varNonZero--] = nums[i];
            }else{
                countZero++;
            }
        }

        for(int i = 0; i<countZero; i++){
            nums[i] = 0;
        }
        System.out.println(Arrays.toString(nums));
    }

}
