package leetcode.array;

public class MergeSortedArray_LC88 {
    public static void main(String[] args) {
        int[] nums1 = {0};
        int[] nums2 = {1};
        int m = 0;
        int n = 1;
        merge(nums1, m, nums2, n);
    }

    public static void merge(int[] nums1, int m, int[] nums2, int n) {
        int k = m+n-1;
        n--;m--;
        while (n >= 0) {
           if(m>=0 && nums1[m] > nums2[n]){
               nums1[k--] = nums1[m--];
           }else{
               nums1[k--] = nums2[n--];
           }

        }
        for (int a : nums1) {
            System.out.println(a);
        }
    }
}
