package leetcode.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.StreamSupport;

public class Practice {
    public static void main(String[] args) {
       String s = ", , , ,        a, eaefa";
        String [] arr = s.split(" ");
        System.out.println(arr.length);
        for(int i=0; i<arr.length;i++){
            System.out.println(arr[i]);
        }

    }
}
