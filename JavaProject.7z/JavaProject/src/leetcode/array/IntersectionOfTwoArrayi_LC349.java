package leetcode.array;

import java.util.*;

public class IntersectionOfTwoArrayi_LC349 {
    public static void main(String[] args) {
        int[] nums1 = {4,7,9,7,6,7};

        int [] nums2 = {5,0,0,6,1,6,2,2,4};
        int [] result = intersectionUsingOnlySet(nums1, nums2);
        for(int val : result){
            System.out.println(val);
        }
    }

    public static int[] intersection(int[] nums1, int[] nums2) {
        HashMap<Integer, Integer> hmap = new HashMap<>();
        Set<Integer> set = new HashSet<>();
        for(int a :nums1){
            if(!hmap.containsKey(a))
                hmap.put(a,1);
        }
        for(int a:nums2){
            if(hmap.containsKey(a)){
                set.add(a);
            }
        }
        int [] result = new int[set.size()];
        int i=0;
        for(int a: set){
            result[i++]= a;
        }
        return result;
    }

    public static int[] intersectionUsingOnlySet(int[] nums1, int[] nums2) {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();
        for(int a: nums1){
            set1.add(a);
        }
        for(int b: nums2){
            if(set1.contains(b)){
                set2.add(b);
            }
        }
        int [] result = new int[set2.size()];
        int i=0;
        for(int a: set2){
            result[i++] = a;
        }
        return result;

    }

}
