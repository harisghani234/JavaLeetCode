package leetcode.array;

import java.util.Arrays;
import java.util.HashMap;

public class TwoSum_LC1 {
    public static void main(String[] args) {
        int [] nums = {2,7,11,15};
        int target = 18;
        int [] arr = twoSum(nums, target);
        System.out.println(Arrays.toString(arr));
    }

    public static int[] twoSum(int[] nums, int target){
        int [] result = new int[2];
        HashMap<Integer, Integer> hmap = new HashMap<>();
        for(int i=0;i<nums.length;i++){
            hmap.put(nums[i],i);
        }
        for(int i=0;i<nums.length;i++){
            int find = target - nums[i];
            if(hmap.containsKey(find)){
                if(i==hmap.get(find))
                    continue;
                result[0]=i;
                result[1]=hmap.get(find);

            }

        }
        return result;
    }

}
