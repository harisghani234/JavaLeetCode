package leetcode.array;

import java.util.Arrays;

public class PlusOne_LC66 {

    public static void main(String[] args) {
        int [] digits = {3,9,9};
        int [] result = plusOne(digits);
        System.out.println(Arrays.toString(result));
//        int i = 1234;
//        int out = 0;
//        while(i>0){
//            int rem = i%10;
//            out = out*10+rem;
//            i = i/10;
//        }
//        System.out.println(out);
    }

    public static int[] plusOne(int[] digits) {
        for(int i=digits.length-1; i>=0; i--){
            if(digits[i]<9){
                digits[i]= digits[i]+1;
                return digits;
            }
            digits[i]=0;
        }
        int[] newDigit = new int[digits.length+1];
        newDigit[0] = 1;
        // by default other indexes are 0 which we want
        return newDigit;
    }
}
