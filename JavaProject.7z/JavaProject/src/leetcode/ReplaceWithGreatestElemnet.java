package leetcode;

import java.util.Arrays;

public class ReplaceWithGreatestElemnet {
    public static void main(String[] args) {

//    Given an array arr, replace every element in that array with the greatest element among the elements to its right, and replace the last element with -1.
        int [] input = {17,18,5,4,6,1};
        int [] output = replaceElementFromRight(input);
        System.out.println(Arrays.toString(output));

    }

    public static int[] reaplaceElement(int [] arr){
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
        int max = arr[arr.length-1];
        arr[arr.length-1]=-1;
        for(int i=arr.length-2;i>=0;i--){
            if(arr[i]>max){
                int temp = arr[i];
                arr[i]= max;
                max = temp;

            }else{
                arr[i]=max;
            }
        }
        return arr;
    }

    public static int[] replaceElementFromRight(int[] arr){
        int max = arr[arr.length-1];
        arr[arr.length-1]=-1;
        for(int i=arr.length-2; i<=0; i--) {
            if (arr[i] > max) {
                int temp = arr[i];
                arr[i] = max;
                max = temp;
            } else {
                arr[i] = max;
            }
        }
        return arr;
    }
}
