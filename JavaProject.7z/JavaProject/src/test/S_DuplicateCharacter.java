package test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class S_DuplicateCharacter  {
    public static void main(String[] args) {

        String s = "haris ghani";
        ArrayList<Character> al = new ArrayList<>();
        Set<Character> set = new HashSet<>();
        for(int i=0;i<s.length();i++){
            if (set.add(s.charAt(i))==false){
                System.out.println("Duplicate character is - "+s.charAt(i));
              al.add(s.charAt(i));
            }
        }
        System.out.println("*******Printing Duplicate Characters********");
        for(int i=0;i<al.size();i++){
            System.out.println(al.get(i));
        }

    }
}
