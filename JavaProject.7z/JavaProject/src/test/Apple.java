package test;

public class Apple {
    public static void main(String[] args) {
       String s = "aaabbaabbbbccddbb";
       // a3b2a2b4c2d2b2
        String output = "";
        for(int i=0;i<s.length();i++){
            int l =i;
            int r = i+1;
            int count = 1;
            output=output+s.charAt(l);
            while(r<s.length() && s.charAt(l)==s.charAt(r)){
                count++;
                l++;r++;
            }
            output=output+count;
            i=--r;
        }

        System.out.println(output);
    }
}
