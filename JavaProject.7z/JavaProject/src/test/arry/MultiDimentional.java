package test.arry;

public class MultiDimentional {
    public static void main(String[] args) {
        int arr[][] = {{1,2},{3,4},{5,6},{4,8}};
        System.out.println(arr[0][1]);
    }
}

