package test;

import java.util.HashMap;
import java.util.Map;

public class S_eachCharCount {
    public static void main(String[] args) {
        String input = "haris ghani";
        HashMap<Character, Integer> hmap = new HashMap<>();
        for(int i=0;i<input.length(); i++){
            if(hmap.containsKey(input.charAt(i))){
                hmap.put(input.charAt(i),hmap.get(input.charAt(i))+1);
            }
            else{
                hmap.put(input.charAt(i),1);
            }
        }
        for(Map.Entry<Character, Integer> entry: hmap.entrySet()){
            System.out.println("key '"+entry.getKey()+ "' has value "+entry.getValue());
        }

    }
}
