package test;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class S_reverseString {
    public static void main(String[] args) {
            String s = "haris ghani";
            StringBuffer sb = new StringBuffer(s);
            int l =0;
            int r=s.length()-1;

            while (l<r)
            {
                char lc= s.charAt(l);
                char rc= s.charAt(r);
                sb.setCharAt(l,rc);
                sb.setCharAt(r,lc);
                l++;
                r--;
            }
        System.out.println(sb);

    }
}