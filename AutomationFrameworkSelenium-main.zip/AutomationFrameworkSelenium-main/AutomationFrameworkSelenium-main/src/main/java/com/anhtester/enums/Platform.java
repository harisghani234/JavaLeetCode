package com.anhtester.enums;

public enum Platform {
    WEB, MOBILE, DESKTOP
}
