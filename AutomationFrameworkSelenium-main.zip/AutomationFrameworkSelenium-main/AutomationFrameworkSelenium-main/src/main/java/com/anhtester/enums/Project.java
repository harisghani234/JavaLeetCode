package com.anhtester.enums;

public enum Project {
    CRM, HRM, ECOMMERCE
}
