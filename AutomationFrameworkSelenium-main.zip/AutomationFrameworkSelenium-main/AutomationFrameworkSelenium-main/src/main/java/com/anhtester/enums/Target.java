package com.anhtester.enums;

public enum Target {
    LOCAL, REMOTE
}
