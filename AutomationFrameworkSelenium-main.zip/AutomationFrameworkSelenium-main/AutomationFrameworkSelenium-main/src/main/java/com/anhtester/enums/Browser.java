package com.anhtester.enums;

/**
 *
 */
public enum Browser {
    /**
     *
     */
    CHROME, EDGE, FIREFOX
}
