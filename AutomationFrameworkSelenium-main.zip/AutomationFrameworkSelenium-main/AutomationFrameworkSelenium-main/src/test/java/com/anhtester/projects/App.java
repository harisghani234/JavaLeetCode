package com.anhtester.projects;

import com.anhtester.utils.LogUtils;
import org.testng.annotations.Test;

public class App {
    public static void main(String[] args) {
        LogUtils.info("Build success !!");
    }
}
